<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Marca;

class MarcaController extends Controller
{
    public function index()
    {
        return Marca::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:100',
            'estado' => 'required|integer',
        ]);

        $marca = Marca::create($request->all());
        return response()->json($marca, 201);
    }

    public function show($id)
    {
        return Marca::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $marca = Marca::find($id);

        if (!$marca) {
            return response()->json(['message' => 'Marca no encontrada'], 404);
        }

        $request->validate([
            'nombre' => 'required|string|max:100',
            'estado' => 'required|integer',
        ]);

        $marca->update($request->all());

        return response()->json($marca, 200);
    }

    public function destroy($id)
    {
        $marca = Marca::find($id);

        if (!$marca) {
            return response()->json(['message' => 'Marca no encontrada'], 404);
        }

        $marca->delete();

        return response()->json(['message' => 'Marca eliminada'], 200);
    }

    public function toggleStatus(Request $request)
    {
        $marca = Marca::find($request->pk_marca);

        if (!$marca) {
            return response()->json(['message' => 'Marca no encontrada'], 404);
        }

        $nuevoEstado = $marca->estado === 1 ? 2 : 1;
        $marca->update(['estado' => $nuevoEstado]);

        return response()->json($marca, 200);
    }
}
