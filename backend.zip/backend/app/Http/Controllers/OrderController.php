<?php

namespace App\Http\Controllers;

use App\Models\ProductoBetter;
use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:usuarios,id',
            'products' => 'required|array',
            'products.*.id' => 'required|exists:productos_better,id',
            'products.*.quantity' => 'required|integer|min:1',
            'total' => 'required|numeric|min:0'
        ]);
    
        $order = Order::create([
            'user_id' => $request->user_id,
            'total' => $request->total
        ]);
    
        foreach ($request->products as $productData) {
            $order->products()->attach($productData['id'], [
                'quantity' => $productData['quantity'],
                'price' => ProductoBetter::find($productData['id'])->precio // Ajuste aquí para 'precio'
            ]);
        }
    
        return response()->json(['message' => 'Order placed successfully'], 201);
    }
    

    public function userOrders($userId)
    {
        $orders = Order::where('user_id', $userId)->with('products')->get();
        return response()->json($orders);
    }



public function updateStatus(Request $request, $id)
{
    $order = Order::find($id);
    if (!$order) {
        return response()->json(['error' => 'Order not found'], 404);
    }

    $order->estado = $request->input('estado');
    $order->save();

    return response()->json($order);
}

public function deleteOrder($id)
{
    $order = Order::find($id);
    if (!$order) {
        return response()->json(['error' => 'Order not found'], 404);
    }

    $order->delete();
    return response()->json(['message' => 'Order deleted']);
}

public function index()
{
    // Carga las órdenes con los usuarios asociados
    $orders = Order::with('user')->get();

    return response()->json($orders);
}


}
