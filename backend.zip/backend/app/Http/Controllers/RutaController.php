<?php

namespace App\Http\Controllers;
use App\Models\Ruta;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RutaController extends Controller
{

    public function getUrl(Request $request)
    {
        $accion = $request->input('accion');
        $ruta = DB::table('rutas')->where('nombre', $accion)->first();

        if ($ruta) {
            return response()->json(['url' => $ruta->url], 200);
        } else {
            return response()->json(['url' => 'bienvenido'], 200); // Redirige al inicio si no se encuentra
        }
    }

}
