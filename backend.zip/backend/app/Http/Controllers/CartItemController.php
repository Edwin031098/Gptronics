<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use Illuminate\Http\Request;

class CartItemController extends Controller
{
   
    public function store(Request $request)
    {
        $request->validate([
            'cart_id' => 'required|exists:carts,id',
            'product_id' => 'required|exists:productos,pk_producto', // Ajusta 'productos' si es necesario
            'quantity' => 'required|integer|min:1',
        ]);

        // Verifica si el ítem ya está en el carrito
        $existingItem = CartItem::where('cart_id', $request->input('cart_id'))
                                ->where('product_id', $request->input('product_id'))
                                ->first();

        if ($existingItem) {
            // Si el ítem ya está en el carrito, actualiza la cantidad
            $existingItem->quantity += $request->input('quantity');
            $existingItem->save();
        } else {
            // Si el ítem no está en el carrito, créalo
            $cartItem = CartItem::create([
                'cart_id' => $request->input('cart_id'),
                'product_id' => $request->input('product_id'),
                'quantity' => $request->input('quantity'),
            ]);
        }

        return response()->json(['message' => 'Cart item updated'], 200);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        $cartItem = CartItem::findOrFail($id);
        $cartItem->update([
            'quantity' => $request->input('quantity'),
        ]);

        return response()->json($cartItem);
    }

    public function destroy($id)
    {
        $cartItem = CartItem::find($id);

        if (!$cartItem) {
            return response()->json(['message' => 'Cart item not found'], 404);
        }

        $cartItem->delete();

        return response()->json(['message' => 'Cart item deleted'], 200);
    }

    public function index(Request $request)
{
    $userId = $request->query('user_id'); // Obtiene el ID del usuario desde la query
    $cartItems = CartItem::where('user_id', $userId)->get(); // Ajusta esto según tu lógica
    return response()->json($cartItems);
}
}
