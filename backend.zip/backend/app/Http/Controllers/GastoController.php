<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Gasto;

class GastoController extends Controller
{
    public function index()
    {
        return Gasto::all();
    }

    public function store(Request $request)
    {
        $data = $request->all();
        $data['fecha'] = $data['fecha'] ?? now()->format('Y-m-d'); // Usa la fecha actual si no se proporciona
    
        $gasto = Gasto::create($data);
    
        return response()->json($gasto);
    }
    
    public function show($id)
    {
        return Gasto::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $gasto = Gasto::findOrFail($id);

        $request->validate([
            'descripcion' => 'required|string|max:255',
            'monto' => 'required|numeric',
            'fecha' => 'required|date',
            'estado' => 'required|integer',
        ]);

        $gasto->update($request->all());

        return response()->json($gasto, 200);
    }

    public function destroy($id)
    {
        Gasto::destroy($id);
        return response()->json(null, 204);
    }
    public function toggleStatus(Request $request)
{
    $gasto = Gasto::find($request->pk_gastos);
    if ($gasto) {
        $gasto->estado = $request->estado;
        $gasto->save();
        return response()->json(['message' => 'Estado actualizado'], 200);
    }
    return response()->json(['message' => 'Gasto no encontrado'], 404);
}

}
