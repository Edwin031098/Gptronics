<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;
use App\Models\Categoria;
use App\Models\Marca;
class ProductoController extends Controller
{
    public function index()
    {
        $productos = Producto::with(['categoria', 'proveedor', 'marca'])->get();
        return response()->json($productos);

        
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'nullable|string|max:50',
            'caracteristicas' => 'nullable|string|max:256',
            'descripcion' => 'nullable|string|max:256',
            'precio' => 'nullable|numeric',
            'stock' => 'nullable|integer',
            'stock_minimo' => 'nullable|integer',
            'FK_categoria' => 'nullable|exists:categorias,pk_categoria',
            'FK_proveedor' => 'nullable|exists:proveedores,id',
            'FK_marca' => 'nullable|exists:marcas,pk_marca',
            'precio_costo' => 'nullable|numeric',
            'precio_mayoreo' => 'nullable|numeric',
            'precio_oferta' => 'nullable|numeric',
            'cantidad_producto_mayoreo' => 'nullable|numeric',
            'estado' => 'nullable|integer',
            'fecha_creacion' => 'nullable|date',
            'codigo_barras' => 'nullable|max:255',
            'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Guardar la imagen si se proporciona
        $imagenPath = null;
        if ($request->hasFile('imagen')) {
            $imagen = $request->file('imagen');
            $imagenPath = $imagen->store('productos', 'public'); // Guarda en storage/app/public/productos
        }

        $data = $request->all();
        $data['imagen'] = $imagenPath; // Asigna la ruta de la imagen al array de datos

        $producto = Producto::create($data);
        return response()->json($producto, 201);
    }

    public function show($id)
    {
        $producto = Producto::with(['categoria', 'proveedor', 'marca'])->find($id);

        if ($producto) {
            return response()->json($producto);
        } else {
            return response()->json(['message' => 'Producto no encontrado'], 404);
        }
    }

public function update(Request $request, $id)
{
    $product = Producto::find($id);
    
    if (!$product) {
        return response()->json(['message' => 'Producto no encontrado'], 404);
    }
    
    // Solo validar campos que estén presentes en la solicitud
    $validatedData = $request->validate([
        'nombre' => 'nullable|max:50',
        'caracteristicas' => 'nullable|max:256',
        'descripcion' => 'nullable|max:256',
        'precio' => 'nullable|numeric|min:0',
        'stock' => 'nullable|integer|min:0',
        'stock_minimo' => 'nullable|integer|min:0',
        'FK_categoria' => 'nullable|integer',
        'FK_proveedor' => 'nullable|integer',
        'FK_marca' => 'nullable|integer',
        'precio_costo' => 'nullable|numeric|min:0',
        'precio_mayoreo' => 'nullable|numeric|min:0',
        'precio_oferta' => 'nullable|numeric|min:0',
        'cantidad_producto_mayoreo' => 'nullable|numeric|min:0',
        'estado' => 'nullable|integer',
        'fecha_creacion' => 'nullable|date',
        'codigo_barras' => 'nullable|max:20',
        'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
    ]);

    // Manejar la carga de la imagen si está presente
    if ($request->hasFile('imagen')) {
        $image = $request->file('imagen');
        $imageName = time() . '.' . $image->extension();
        $image->move(public_path('storage'), $imageName);
        $validatedData['imagen'] = $imageName;
    }

    // Actualizar solo los campos que están presentes en la solicitud
    $product->update($validatedData);

    return response()->json(['message' => 'Producto actualizado correctamente'], 200);
}

    public function destroy($id)
    {
        $producto = Producto::find($id);

        if ($producto) {
            $producto->delete();
            return response()->json(['message' => 'Producto eliminado']);
        } else {
            return response()->json(['message' => 'Producto no encontrado'], 404);
        }
    }

    public function increaseStock(Request $request, $id)
    {
        // Valida la cantidad enviada
        $request->validate([
            'quantity' => 'required|integer|min:1', // Permite solo valores positivos
        ]);
    
        $product = Producto::findOrFail($id);
        $product->stock += $request->input('quantity'); // Aumenta el stock
        $product->save();
    
        return response()->json(['message' => 'Stock aumentado exitosamente.'], 200);
    }
    
    public function decreaseStock(Request $request, $id)
    {
        // Valida la cantidad enviada
        $request->validate([
            'quantity' => 'required|integer|min:1', // Permite solo valores positivos
        ]);
    
        $product = Producto::findOrFail($id);
        $product->stock -= $request->input('quantity'); // Disminuye el stock
    
        // Asegúrate de que el stock no quede negativo
        if ($product->stock < 0) {
            return response()->json(['message' => 'El stock no puede ser negativo.'], 400);
        }
    
        $product->save();
    
        return response()->json(['message' => 'Stock disminuido exitosamente.'], 200);
    }
    public function updateImage(Request $request, $id)
    {
        // Validar que el archivo de imagen esté presente
        $request->validate([
            'imagen' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $product = Producto::find($id);

        if (!$product) {
            return response()->json(['message' => 'Producto no encontrado'], 404);
        }

        // Manejar la carga de la nueva imagen
        if ($request->hasFile('imagen')) {
            $file = $request->file('imagen');
            $filePath = $file->store('productos', 'public'); // Guarda la imagen en storage/app/public/productos

            // Actualizar la URL de la imagen en la base de datos
            $product->imagen = $filePath;
            $product->save();
        }

        return response()->json(['message' => 'Imagen actualizada con éxito'], 200);
    }
    public function validateStock($productId, $quantity)
    {
        $product = Producto::find($productId);
    
        if (!$product) {
            return response()->json(['error' => 'Producto no encontrado'], 404);
        }
    
        $isAvailable = $product->stock >= $quantity;
    
        return response()->json(['isAvailable' => $isAvailable]);
    }

   

   

}


