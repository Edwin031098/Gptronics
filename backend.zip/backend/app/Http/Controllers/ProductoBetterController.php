<?php

namespace App\Http\Controllers;

use App\Models\ProductoBetter;
use Illuminate\Http\Request;

class ProductoBetterController extends Controller
{
    // Mostrar todos los productos
    public function index()
    {
        return ProductoBetter::all();
    }

    // Mostrar un producto específico
    public function show($id)
    {
        $producto = ProductoBetter::find($id);
        if ($producto) {
            return response()->json($producto);
        }
        return response()->json(['error' => 'Producto no encontrado'], 404);
    }

    // Crear un nuevo producto
    public function store(Request $request)
    {
        $request->validate([
            'codigo' => 'required|string|max:255',
            'nombre' => 'required|string|max:255',
            'precio' => 'required|numeric',
            'categoria' => 'required|string|max:255',
            'estado' => 'required|integer|in:0,1',
        ]);

        $producto = ProductoBetter::create($request->all());
        return response()->json($producto, 201);
    }

    // Actualizar un producto existente
    public function update(Request $request, $id)
    {
        $request->validate([
            'codigo' => 'string|max:255',
            'nombre' => 'string|max:255',
            'precio' => 'numeric',
            'categoria' => 'string|max:255',
            'estado' => 'integer|in:0,1',
        ]);

        $producto = ProductoBetter::find($id);
        if (!$producto) {
            return response()->json(['error' => 'Producto no encontrado'], 404);
        }

        $producto->update($request->all());
        return response()->json($producto);
    }

    // Eliminar un producto
    public function destroy($id)
    {
        $producto = ProductoBetter::find($id);
        if (!$producto) {
            return response()->json(['error' => 'Producto no encontrado'], 404);
        }

        $producto->delete();
        return response()->json(['message' => 'Producto eliminado']);
    }
}
