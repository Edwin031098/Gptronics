<?php

namespace App\Http\Controllers;

use App\Models\Venta;
use App\Models\VentaProducto;
use Illuminate\Http\Request;

class VentaController extends Controller
{
    public function store(Request $request)
    {
        // Validar datos
        $request->validate([
            'productos' => 'required|array',
            'productos.*.pk_producto' => 'required|exists:productos,pk_producto',
            'productos.*.cantidad' => 'required|integer|min:1',
            'productos.*.precio' => 'required|numeric'
        ]);

        foreach ($request->productos as $producto) {
            $stock = \DB::table('productos')->where('pk_producto', $producto['pk_producto'])->value('stock');
            if ($stock < $producto['cantidad']) {
                // Retornar error si hay stock insuficiente
                return response()->json(['error' => 'Stock insuficiente para el producto ' . $producto['pk_producto']], 400);
            }
        }

        // Crear una nueva venta
        $venta = Venta::create([
            'total' => 0 // Se actualizará más tarde
        ]);

        $total = 0;

        foreach ($request->productos as $producto) {
            // Registrar el producto en la venta
            VentaProducto::create([
                'venta_id' => $venta->id,
                'pk_producto' => $producto['pk_producto'],
                'cantidad' => $producto['cantidad'],
                'precio' => $producto['precio']
            ]);

            // Calcular total
            $total += $producto['precio'] * $producto['cantidad'];

            // Actualizar stock
            \DB::table('productos')->where('pk_producto', $producto['pk_producto'])->decrement('stock', $producto['cantidad']);
        }

        // Actualizar el total de la venta
        $venta->update(['total' => $total]);

        return response()->json(['venta' => $venta], 201);
    }
}