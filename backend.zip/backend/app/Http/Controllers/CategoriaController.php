<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;

class CategoriaController extends Controller
{
    public function index()
    {
        return Categoria::all();
    }

    public function store(Request $request)
    {
        // Establece el estado predeterminado como 1 al crear una nueva categoría
        $data = $request->validate([
            'nombre' => 'required|string|max:100'
        ]);
        $data['estado'] = 1;

        $categoria = Categoria::create($data);
        return response()->json($categoria, 201);
    }

    public function show($id)
    {
        return Categoria::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $categoria = Categoria::find($id);

        if (!$categoria) {
            return response()->json(['message' => 'Categoría no encontrada'], 404);
        }

        // Solo permite actualizar el campo 'nombre' y 'estado' durante la edición
        $data = $request->validate([
            'nombre' => 'required|string|max:100',
            'estado' => 'required|integer'
        ]);

        $categoria->update($data);

        return response()->json($categoria, 200);
    }

    public function destroy($id)
    {
        $categoria = Categoria::find($id);

        if (!$categoria) {
            return response()->json(['message' => 'Categoría no encontrada'], 404);
        }

        $categoria->delete();

        return response()->json(['message' => 'Categoría eliminada'], 200);
    }
}
