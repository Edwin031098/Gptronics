<?php
// app/Http/Controllers/CartController.php
// app/Http/Controllers/CartController.php
namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Usuario;
use Illuminate\Http\Request;
use App\Models\CartItem;

class CartController extends Controller
{   
     public function index(Request $request)
     {
        // Obtén el user_id de la solicitud
        $userId = $request->input('user_id');
        
        if (!$userId) {
            return response()->json(['message' => 'User ID is required'], 400);
        }

        // Busca el carrito del usuario
        $cart = Cart::where('user_id', $userId)->first();

        // Verifica si el carrito existe
        if ($cart) {
            // Devuelve el carrito con los productos
            return response()->json($cart->load('items.product'));
        }

        // Si el carrito no se encuentra, devuelve un mensaje de error
        return response()->json(['message' => 'Cart not found'], 404);
    }

    public function getCartByUserId(Request $request)
{
    $userId = $request->query('user_id');

    // Busca un carrito existente o crea uno nuevo si no existe
    $cart = Cart::firstOrCreate(['user_id' => $userId]);

    return response()->json($cart);
}

    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:usuarios,id',
        ]);

        $cart = Cart::create([
            'user_id' => $request->input('user_id'),
        ]);

        return response()->json($cart, 201);
    }

    public function show($userId)
    {
        $cart = Cart::where('user_id', $userId)
                    ->with('items.product')
                    ->first();
    
        if (!$cart) {
            return response()->json(['message' => 'Cart not found'], 404);
        }
    
        // Debug: Mostrar los ítems del carrito y los productos asociados
        foreach ($cart->items as $item) {
            logger()->info('CartItem:', ['item' => $item, 'product' => $item->product]);
        }
    
        return response()->json($cart);
    }
    
    public function clear(Request $request)
    {
        $userId = $request->input('user_id');
        
        // Verificar si el usuario existe
        $user = Usuario::find($userId);
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }
    
        try {
            // Obtener el carrito del usuario
            $cart = Cart::where('user_id', $userId)->first();
            
            if (!$cart) {
                return response()->json(['message' => 'Cart not found'], 404);
            }
            
            // Eliminar todos los productos del carrito
            CartItem::where('cart_id', $cart->id)->delete();
            
            return response()->json(['message' => 'Cart items cleared successfully'], 200);
        } catch (\Exception $e) {
            // Manejar cualquier error que pueda ocurrir
            return response()->json([
                'message' => 'An error occurred while clearing the cart items',
                'error' => $e->getMessage() // Agregar mensaje de error para depuración
            ], 500);
        }
    }
}
