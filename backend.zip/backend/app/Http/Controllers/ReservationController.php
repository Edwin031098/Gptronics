<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use App\Models\ReservationDetail;
use App\Models\Producto; // Cambiado a Producto
use Illuminate\Support\Facades\Auth;
use App\Models\Venta; // Importar el modelo Venta
use App\Models\VentaProducto; // Importar el modelo VentaProducto

class ReservationController extends Controller
{
    // Método para reservar productos
    public function reserve(Request $request)
    {
        $userId = $request->input('user_id');
        $products = $request->input('products'); // Asume que es un array de productos con pk_producto y quantity
          // Validación
          $validatedData = $request->validate([
            'user_id' => 'required|integer|exists:usuarios,id',
            'products' => 'required|array',
            'products.*.pk_producto' => 'required|integer|exists:productos,pk_producto',
            'products.*.quantity' => 'required|integer|min:1'
        ]);

        // Crear una nueva reserva
        $reservation = Reservation::create([
            'user_id' => $userId,
            'status' => 'pending', // Puede ser 'pending', 'accepted', o 'expired'
            'total' => 0 // Se actualizará después con el total
        ]);
    
        $total = 0;
    
        foreach ($products as $productData) {
            $product = Producto::find($productData['pk_producto']);
    
            if ($product && $product->stock >= $productData['quantity']) {
                $price = $product->precio * $productData['quantity']; // Asegúrate de usar el precio correcto
                $total += $price;
    
                // Crear un detalle de la reserva
                ReservationDetail::create([
                    'reservation_id' => $reservation->id,
                    'pk_producto' => $productData['pk_producto'],
                    'quantity' => $productData['quantity'],
                    'price' => $price // Asegúrate de usar el precio calculado aquí
                ]);
    
           
                
            } else {
                return response()->json(['error' => 'Insufficient stock for product ID ' . $productData['pk_producto']], 400);
            }
        }
    
        // Actualizar el total de la reserva
        $reservation->total = $total;
        $reservation->save();
    
        return response()->json(['message' => 'Reservation created successfully', 'reservation' => $reservation], 201);
    }
    

    // Obtener reservas de un usuario específico
    public function getUserReservations(Request $request)
    {
        // Obtener el ID del usuario desde la solicitud (debe estar en el cuerpo de la solicitud, por ejemplo)
        $userId = $request->input('user_id');
    
        // Verificar si el ID del usuario fue proporcionado
        if (!$userId) {
            return response()->json(['error' => 'User ID is required'], 400);
        }
    
        // Obtener reservas del usuario
        $reservations = Reservation::where('user_id', $userId)
            ->with('details')
            ->get();
    
        return response()->json($reservations);
    }
    
    

    // Método para obtener todas las reservas (para administrador)
    public function getAllReservations()
    {
        $reservations = Reservation::with('details.product', 'user')->get();
    
        return response()->json($reservations);
    }

    // Método para cancelar una reserva
    public function cancelReservation($id)
    {
        $reservation = Reservation::find($id);

        if ($reservation) {
            foreach ($reservation->details as $detail) {
                $product = Producto::find($detail->product_id);
                if ($product) {
                    $product->stock += $detail->quantity;
                    $product->save();
                }
            }

            $reservation->delete();

            return response()->json(['message' => 'Reservation canceled successfully']);
        }

        return response()->json(['error' => 'Reservation not found'], 404);
    }

    public function getReservationDetails($reservationId)
    {
        $reservation = Reservation::with('details.product')->find($reservationId);
    
        if (!$reservation) {
            return response()->json(['message' => 'Reserva no encontrada'], 404);
        }
    

        



        // Transformar los detalles de la reserva para incluir la información del producto
        $details = $reservation->details->map(function ($detail) {
            return [
                'id' => $detail->id,
                'reservation_id' => $detail->reservation_id,
                'pk_producto' => $detail->product->pk_producto ?? null,
                'nombre' => $detail->product->nombre ?? 'No disponible',
                'imagen' => $detail->product->imagen ?? 'No disponible',
                'quantity' => $detail->quantity,
                'price' => $detail->price,
                'created_at' => $detail->created_at,
                'updated_at' => $detail->updated_at,
            ];
        });

            // Calcular el total de la reserva
    $total = $reservation->details->sum(function ($detail) {
        return $detail->quantity * $detail->price;
    });
    
    return response()->json([
        'details' => $details,
        'total' => $total
    ]);
}

public function acceptReservation($id, Request $request)
{
    $reservation = Reservation::find($id);

    if (!$reservation) {
        return response()->json(['error' => 'Reservation not found'], 404);
    }

    $today = now()->startOfDay();

    $dateToPick = $request->input('fecha_recoger');
    if (strtotime($dateToPick) < strtotime($today)) {
        return response()->json(['error' => 'Pick-up date must be today or in the future'], 400);
    }

    // Cambiar el estado a 'accepted' y guardar la fecha de recogida
    $reservation->status = 'accepted';
    $reservation->fecha_recoger = $dateToPick;
    $reservation->save();

    // Obtener todos los detalles de la reserva
    $reservationDetails = ReservationDetail::where('reservation_id', $id)->get();

    foreach ($reservationDetails as $detail) {
        // Obtener el producto
        $product = Producto::find($detail->pk_producto);

        if ($product) {
            // Restar la cantidad del stock
            $product->stock -= $detail->quantity;
            $product->save();
        } else {
            return response()->json(['error' => 'Product not found'], 404);
        }
    }

    return response()->json($reservation);
}

public function markAsCollected($id)
{
    $reservation = Reservation::find($id);

    if (!$reservation) {
        return response()->json(['error' => 'Reservation not found'], 404);
    }

    // 1. Actualizar el estado de la reserva a 'collected'
    $reservation->status = 'collected';
    $reservation->save();

    // 2. Crear una nueva venta
    $venta = new Venta(); // Asegúrate de que el modelo Venta esté importado y configurado
    $venta->total = $reservation->total;
    $venta->created_at = now();
    $venta->updated_at = now();
    $venta->save();

    // 3. Registrar los productos asociados a la reserva en la tabla `venta_producto`
    $reservationDetails = ReservationDetail::where('reservation_id', $id)->get();

    foreach ($reservationDetails as $detail) {
        $ventaProducto = new VentaProducto(); // Asegúrate de que el modelo VentaProducto esté importado y configurado
        $ventaProducto->venta_id = $venta->id;
        $ventaProducto->pk_producto = $detail->pk_producto;
        $ventaProducto->cantidad = $detail->quantity;
        $ventaProducto->precio = $detail->price;
        $ventaProducto->created_at = now();
        $ventaProducto->updated_at = now();
        $ventaProducto->save();
    }

    return response()->json(['message' => 'Reservation marked as collected and sale recorded']);
}


}
