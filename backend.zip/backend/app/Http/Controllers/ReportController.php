<?php

namespace App\Http\Controllers;
use App\Models\Venta;
use App\Models\VentaProducto;
use App\Models\Gasto;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
     // Ventas por día
     public function ventasPorDia(Request $request)
     {
         $date = $request->input('date', now()->format('Y-m-d'));
         $ventas = Venta::whereDate('created_at', $date)->sum('total');
 
         return response()->json(['total_ventas' => $ventas]);
     }
 
     // Ventas por semana
     public function ventasPorSemana(Request $request)
     {
         $startOfWeek = now()->startOfWeek();
         $endOfWeek = now()->endOfWeek();
         $ventas = Venta::whereBetween('created_at', [$startOfWeek, $endOfWeek])->sum('total');
 
         return response()->json(['total_ventas' => $ventas]);
     }
 
     // Ventas por mes
     public function ventasPorMes(Request $request)
     {
         $month = $request->input('month', now()->format('Y-m'));
         $ventas = Venta::whereMonth('created_at', $month)->sum('total');
 
         return response()->json(['total_ventas' => $ventas]);
     }
 
     // Producto más vendido
     public function productoMasVendido()
     {
         $producto = VentaProducto::select('pk_producto', DB::raw('SUM(cantidad) as total_vendido'))
             ->groupBy('pk_producto')
             ->orderBy('total_vendido', 'desc')
             ->first();
 
         $producto_info = Producto::find($producto->pk_producto);
 
         return response()->json([
             'producto' => $producto_info,
             'cantidad_vendida' => $producto->total_vendido
         ]);
     }
 
     // Ganancia por mes
     public function gananciaPorMes(Request $request)
     {
         $month = $request->input('month', now()->format('Y-m'));
         $ventas = Venta::whereMonth('created_at', $month)->sum('total');
         $gastos = Gasto::whereMonth('fecha', $month)->sum('monto');
 
         $ganancia = $ventas - $gastos;
 
         return response()->json([
             'ventas' => $ventas,
             'gastos' => $gastos,
             'ganancia' => $ganancia
         ]);
     }
 
     // Ganancia por día
     public function gananciaPorDia(Request $request)
     {
         $date = $request->input('date', now()->format('Y-m-d'));
         $ventas = Venta::whereDate('created_at', $date)->sum('total');
         $gastos = Gasto::whereDate('fecha', $date)->sum('monto');
 
         $ganancia = $ventas - $gastos;
 
         return response()->json([
             'ventas' => $ventas,
             'gastos' => $gastos,
             'ganancia' => $ganancia
         ]);
     }
 
     // Ganancia por semana
     public function gananciaPorSemana(Request $request)
     {
         $startOfWeek = now()->startOfWeek();
         $endOfWeek = now()->endOfWeek();
         $ventas = Venta::whereBetween('created_at', [$startOfWeek, $endOfWeek])->sum('total');
         $gastos = Gasto::whereBetween('fecha', [$startOfWeek, $endOfWeek])->sum('monto');
 
         $ganancia = $ventas - $gastos;
 
         return response()->json([
             'ventas' => $ventas,
             'gastos' => $gastos,
             'ganancia' => $ganancia
         ]);
     }
 
     // Productos con stock bajo
     public function productosConStockBajo() {
        $productos = DB::table('productos')
            ->whereColumn('stock', '<', 'stock_minimo')
            ->get();
        
        return response()->json($productos);
    }
    public function getGastos()
    {
        $gastos = Gasto::all(); // Obtén todos los registros de gastos

        return response()->json($gastos);
    }
}    