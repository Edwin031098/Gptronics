<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Cart;

class AuthController extends Controller
{


    public function index()
    {
        $usuarios = Usuario::all();
        return response()->json($usuarios);
    }

    public function update(Request $request, $id)
    {
        $usuario = Usuario::find($id);
        if ($usuario) {
            $usuario->role = $request->input('role');
            $usuario->save();
            return response()->json($usuario);
        }
        return response()->json(['message' => 'Usuario no encontrado'], 404);
    }


    public function register(Request $request)
    {
        // Validar los datos de entrada
        $validator = Validator::make($request->all(), [
            'correo' => 'required|email|unique:usuarios',
            'clave' => 'required|min:6',
            'nombre' => 'required|string|max:255',
            'telefono' => 'required|string|max:15', // Ajusta la validación según tus necesidades
        ]);
    
        // Retornar errores de validación si los hay
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
    
        // Crear un nuevo usuario
        $usuario = Usuario::create([
            'correo' => $request->correo,
            'clave' => Hash::make($request->clave),
            'nombre' => $request->nombre,
            'telefono' => $request->telefono, // Incluye el campo telefono
        ]);

            // Crear el carrito asociado al usuario
             $cart = Cart::create([
             'user_id' => $usuario->id,
              ]);
    
        // Retornar respuesta de éxito
        return response()->json(['message' => 'Usuario registrado correctamente'], 201);
    }
    
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'correo' => 'required|email',
            'clave' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        $usuario = Usuario::where('correo', $request->correo)->first();

        if (!$usuario || !Hash::check($request->clave, $usuario->clave)) {
            return response()->json(['error' => 'Credenciales inválidas'], 401);
        }

        // Login exitoso, incluir el nombre y rol del usuario en la respuesta
        return response()->json([
            'message' => 'Login exitoso',
            'nombre' => $usuario->nombre, // Incluir el nombre del usuario
            'role' => $usuario->role, // Incluir el rol del usuario (debes tener este campo en tu modelo)
            'userId' => $usuario->id // Asegúrate de incluir el ID del usuario

        ], 200);
    }
}