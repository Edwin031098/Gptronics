<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Marca extends Model
{
    // Define la tabla asociada con el modelo
    protected $table = 'marcas';

    // Define la clave primaria
    protected $primaryKey = 'pk_marca';

    // Establece que la clave primaria no es autoincremental
    public $incrementing = true;

    // Establece el tipo de la clave primaria
    protected $keyType = 'int';

    // Define los atributos que son asignables en masa
    protected $fillable = ['nombre', 'estado'];

    // Define los atributos que deberían ser mutados a fechas
    protected $dates = ['created_at', 'updated_at'];
}
