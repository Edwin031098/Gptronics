<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;

    // Define la clave primaria
    protected $primaryKey = 'pk_categoria';

    // No se espera la columna `id`
    public $incrementing = false;

    // No es tipo `integer`, define el tipo explícitamente si es necesario
    protected $keyType = 'string';

    // Define los campos que se pueden llenar masivamente
    protected $fillable = ['nombre', 'estado', 'fecha_creacion'];

    protected $attributes = [
        'estado' => 1,
    ];

    public $timestamps = false; // Si no estás usando timestamps automáticos

    
}