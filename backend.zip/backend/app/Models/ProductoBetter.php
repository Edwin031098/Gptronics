<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class ProductoBetter extends Model
{
    use HasFactory;

    // Define la tabla asociada con el modelo
    protected $table = 'productos_better';

    // Define los campos que son asignables en masa
    protected $fillable = [
        'codigo',
        'nombre',
        'precio',
        'categoria',
        'estado'
    ];

    // Si no deseas usar timestamps, puedes desactivarlos
    public $timestamps = true;

    public function orders()
    {
        return $this->belongsToMany(Order::class, 'order_product', 'product_id', 'order_id')
                    ->withPivot('quantity', 'price')
                    ->withTimestamps();
    }
}