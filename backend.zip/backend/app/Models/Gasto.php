<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gasto extends Model
{
    use HasFactory;

    // Define la clave primaria personalizada
    protected $primaryKey = 'pk_gastos';
    
    // Indica si la clave primaria es auto-incremental
    public $incrementing = true;

    // Define el tipo de clave primaria
    protected $keyType = 'int'; // o 'string' si es un tipo de dato diferente

    // Define los campos que pueden ser asignados masivamente
    protected $fillable = [
        'descripcion',
        'monto',
        'fecha',
        'estado'
    ];

    // Opcional: Si no deseas que Laravel maneje las marcas de tiempo
    // public $timestamps = false;
}