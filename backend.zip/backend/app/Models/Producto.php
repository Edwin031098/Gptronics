<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    
    protected $primaryKey = 'pk_producto'; // Clave primaria

    protected $fillable = [
        'nombre',
        'caracteristicas',
        'descripcion',
        'precio',
        'stock',
        'stock_minimo',
        'FK_categoria',
        'FK_proveedor',
        'FK_marca',
        'precio_costo',
        'precio_mayoreo',
        'precio_oferta',
        'cantidad_producto_mayoreo',
        'estado',
        'fecha_creacion',
        'codigo_barras', // Agrega este campo
        'imagen',

    ];

    // Relación con Categoria
    public function categoria()
    {
        return $this->belongsTo(Categoria::class, 'FK_categoria', 'pk_categoria');
    }

    // Relación con Proveedor
    public function proveedor()
    {
        return $this->belongsTo(Proveedor::class, 'FK_proveedor', 'id');
    }

    // Relación con Marca
    public function marca()
    {
        return $this->belongsTo(Marca::class, 'FK_marca', 'pk_marca');
    }
}
