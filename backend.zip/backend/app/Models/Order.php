<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $table = 'orders'; // Ajusta esto según el nombre de tu tabla de órdenes


    protected $fillable = [
        'user_id', 'total', 'status', 'created_at'
    ];
    public function products()
    {
        return $this->belongsToMany(ProductoBetter::class, 'order_product', 'order_id', 'product_id')
                    ->withPivot('quantity', 'price')
                    ->withTimestamps();
    
                }
                public function user()
                {
                    return $this->belongsTo(Usuario::class, 'user_id');
                }
            
            }
