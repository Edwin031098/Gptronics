<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Venta extends Model
{
    use HasFactory;
    
    protected $fillable = ['total', 'created_at', 'updated_at'];

    protected $table = 'ventas';
    public function productos()
    {
        return $this->hasMany(VentaProducto::class, 'venta_id');
    }
}