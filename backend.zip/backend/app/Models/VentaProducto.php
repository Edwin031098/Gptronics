<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VentaProducto extends Model
{
    use HasFactory;
    protected $table = 'venta_producto'; // Asegúrate de que el nombre es correcto

    protected $fillable = ['venta_id', 'pk_producto', 'cantidad', 'precio', 'created_at', 'updated_at'];

    public function venta()
    {
        return $this->belongsTo(Venta::class, 'venta_id');
    }

    public function producto()
    {
        return $this->belongsTo(Producto::class, 'pk_producto', 'pk_producto');
    }
}