<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable; // Cambiado de Model a Authenticatable
use Illuminate\Notifications\Notifiable;

class Usuario extends Authenticatable
{
    use HasFactory, Notifiable; // Utilizar los traits necesarios

    protected $table = 'usuarios'; // Nombre de la tabla en la base de datos
    protected $fillable = ['correo', 'clave', 'nombre', 'role','telefono','estado',]; // Añadir el campo role a los fillables

    // Opcional: Si la tabla tiene columnas created_at y updated_at
    public $timestamps = true;

    // Añadir los campos que se deben ocultar en arrays
    protected $hidden = [
        'clave',
    ];

    // Método para buscar usuario por correo
    public function findForPassport($username)
    {
        return $this->where('correo', $username)->first();
    }
    public function reservations()
    {
        return $this->hasMany(Reservation::class, 'user_id');
    }
    
}
