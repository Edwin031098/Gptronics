<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReservationDetail extends Model
{
    use HasFactory;

    protected $table = 'reservation_details'; // Nombre de la tabla en la base de datos

    protected $fillable = [
        'reservation_id', 
        'pk_producto',
        'quantity',
        'price',
        'nombre',
        'imagen'
    ];

    // Relación con Reservation
    public function reservation()
    {
        return $this->belongsTo(Reservation::class, 'reservation_id');
    }

    // Relación con Product
    public function product()
    {
        return $this->belongsTo(Producto::class, 'pk_producto'); // Asegúrate de que los campos coincidan
    }
}
