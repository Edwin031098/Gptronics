<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RutaController;
use App\Http\Controllers\ProveedorController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\MarcaController;
use App\Http\Controllers\GastoController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\VentaController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CartItemController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ProductoBetterController;
use App\Http\Controllers\OrderController;

;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);
Route::post('/get-url', [RutaController::class, 'getUrl']);

// Proveedores CRUD
Route::get('proveedores', [ProveedorController::class, 'index']); // Listar todos los proveedores
Route::post('proveedores', [ProveedorController::class, 'store']); // Crear nuevo proveedor
Route::get('proveedores/{id}', [ProveedorController::class, 'show']); // Mostrar un proveedor específico
Route::put('proveedores/{id}', [ProveedorController::class, 'update']); // Actualizar un proveedor
Route::delete('proveedores/{id}', [ProveedorController::class, 'destroy']); // Eliminar un proveedor


// CATEGORIAS CRUD
Route::get('/categorias', [CategoriaController::class, 'index']);
Route::post('/categorias', [CategoriaController::class, 'store']);
Route::get('/categorias/{id}', [CategoriaController::class, 'show']);
Route::put('/categorias/{id}', [CategoriaController::class, 'update']);
Route::delete('/categorias/{id}', [CategoriaController::class, 'destroy']);
Route::post('/categorias/toggle-status', [CategoriaController::class, 'toggleStatus']); // Ruta para activar/desactivar
Route::post('/categorias/{id}/cambiar-estado', [CategoriaController::class, 'cambiarEstado']); // Nueva ruta

// MARCAS CRUD
Route::apiResource('marcas', MarcaController::class);
Route::post('marcas/toggle-status', [MarcaController::class, 'toggleStatus']);

// GASTOS CRUD
Route::get('gastos', [GastoController::class, 'index']);
Route::post('gastos', [GastoController::class, 'store']);
Route::get('gastos/{id}', [GastoController::class, 'show']);
Route::put('gastos/{id}', [GastoController::class, 'update']);
Route::delete('gastos/{id}', [GastoController::class, 'destroy']);
// En web.php o api.php (según corresponda)
Route::post('/gastos/toggle-status', [GastoController::class, 'toggleStatus']);

// PRODUCTOS CRUD
Route::get('/product/{productId}/stock/{quantity}', [ProductoController::class, 'validateStock']);

Route::prefix('productos')->group(function () {
    Route::get('/', [ProductoController::class, 'index'])->name('productos.index');
    Route::get('/create', [ProductoController::class, 'create'])->name('productos.create');
    Route::post('/', [ProductoController::class, 'store'])->name('productos.store');
    Route::get('{id}', [ProductoController::class, 'show'])->name('productos.show');
    Route::get('{id}/edit', [ProductoController::class, 'edit'])->name('productos.edit');
    Route::put('{id}', [ProductoController::class, 'update'])->name('productos.update');
    Route::delete('{id}', [ProductoController::class, 'destroy'])->name('productos.destroy');
    Route::post('{id}/stock/increase', [ProductoController::class, 'increaseStock'])->name('productos.stock.increase');
    Route::post('{id}/stock/decrease', [ProductoController::class, 'decreaseStock'])->name('productos.stock.decrease');
    Route::post('/{id}/update-image', [ProductoController::class, 'updateImage']);
    Route::get('/categorias', [ProductoController::class, 'getCategories']);

Route::get('/brands', [ProductoController::class, 'getBrands']);
});



    Route::get('/carts', [CartController::class, 'index']); // Para obtener el carrito por user_id
    Route::post('/carts', [CartController::class, 'store']); // Para crear un nuevo carrito
    Route::get('/carts/count/{userId}', [CartController::class, 'getCartCount']);


    Route::get('/cart/{userId}', [CartController::class, 'show']);

    Route::post('/cart-items', [CartItemController::class, 'store']);
    Route::put('/cart-items/{id}', [CartItemController::class, 'update']);
    Route::delete('/cart-items/{id}', [CartItemController::class, 'destroy']);
    Route::get('/cart-items', [CartItemController::class, 'index']); // Para obtener los elementos del carrito
    Route::post('/cart/clear', [CartController::class, 'clear']);


    Route::post('/reservations', [ReservationController::class, 'reserve']);
    Route::post('/reservations/cart_reserve', [ReservationController::class, 'reserve']);
    Route::get('/reservations/user', [ReservationController::class, 'getUserReservations']);
    Route::get('/reservations', [ReservationController::class, 'getAllReservations']);
    Route::delete('/reservations/{id}', [ReservationController::class, 'cancelReservation']);
    Route::get('/reservation-details/{reservationId}', [ReservationController::class, 'getReservationDetails']);
    Route::put('reservations/{id}/accept', [ReservationController::class, 'acceptReservation']);
    Route::put('reservations/{id}/mark-as-collected', [ReservationController::class, 'markAsCollected']);
    


    Route::get('reportes/ventas-dia', [ReportController::class, 'ventasPorDia']);
Route::get('reportes/ventas-semana', [ReportController::class, 'ventasPorSemana']);
Route::get('reportes/ventas-mes', [ReportController::class, 'ventasPorMes']);
Route::get('reportes/producto-mas-vendido', [ReportController::class, 'productoMasVendido']);
Route::get('reportes/ganancia-mes', [ReportController::class, 'gananciaPorMes']);
Route::get('reportes/ganancia-dia', [ReportController::class, 'gananciaPorDia']);
Route::get('reportes/ganancia-semana', [ReportController::class, 'gananciaPorSemana']);
Route::get('reportes/productos-stock-bajo', [ReportController::class, 'productosConStockBajo']);
Route::get('reportes/gastos', [ReportController::class, 'getGastos']);

Route::get('/orders', [OrderController::class, 'index']);

Route::post('/orders', [OrderController::class, 'store']);
Route::get('/orders/{userId}', [OrderController::class, 'userOrders']);

Route::delete('/orders/{id}', [OrderController::class, 'deleteOrder']);

Route::apiResource('productos-better', ProductoBetterController::class);


Route::get('/usuarios', [AuthController::class, 'index']);
Route::put('/usuarios/{id}', [AuthController::class, 'update']);

Route::get('/productos', [ProductoController::class, 'index']);
Route::post('/ventas', [VentaController::class, 'store']);

Route::get('productos', [ProductoController::class, 'index']);



Route::get('/user', function (Request $request) {
    return $request->user();
});
