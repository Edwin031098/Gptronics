<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductosTable extends Migration
{
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->id('pk_producto');
            $table->string('nombre', 50);
            $table->string('caracteristicas', 256);
            $table->string('descripcion', 256);
            $table->decimal('precio', 20, 2);
            $table->integer('stock');
            $table->integer('stock_minimo');
            $table->foreignId('FK_categoria')->constrained('categorias', 'pk_categoria'); // Ajustar según la columna
            $table->foreignId('FK_proveedor')->constrained('proveedores'); // Ajustar según la columna
            $table->foreignId('FK_marca')->constrained('marcas', 'pk_marca'); // Ajustar según la columna
            $table->decimal('precio_costo', 20, 2);
            $table->decimal('precio_mayoreo', 20, 3);
            $table->decimal('precio_oferta', 20, 4);
            $table->decimal('cantidad_producto_mayoreo', 20, 2);
            $table->integer('estado');
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
