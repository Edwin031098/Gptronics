<?php

// database/migrations/xxxx_xx_xx_xxxxxx_create_cart_items_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCartItemsTable extends Migration
{
    public function up()
    {
        Schema::create('cart_items', function (Blueprint $table) {
            $table->id(); // id del ítem del carrito
            $table->unsignedBigInteger('cart_id'); // id del carrito al que pertenece el ítem
            $table->unsignedBigInteger('product_id'); // id del producto
            $table->integer('quantity'); // cantidad del producto
            $table->timestamps(); // timestamps para created_at y updated_at

            // Relación con la tabla de carritos
            $table->foreign('cart_id')->references('id')->on('carts')->onDelete('cascade');

            // Relación con la tabla de productos
            $table->foreign('product_id')->references('pk_producto')->on('productos')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('cart_items');
    }
}
