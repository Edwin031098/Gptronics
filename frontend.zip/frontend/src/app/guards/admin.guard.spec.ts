import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminGuard } from './admin.guard'; // Asegúrate de que esta ruta es correcta
import { AuthService } from '../services/auth.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';

describe('AdminGuard', () => {
  let guard: AdminGuard;
  let authService: AuthService;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AdminGuard,
        {
          provide: AuthService,
          useValue: {
            isAuthenticated$: of(true),
            userRole$: of('admin')
          }
        }
      ]
    });

    guard = TestBed.inject(AdminGuard);
    authService = TestBed.inject(AuthService);
    router = TestBed.inject(Router);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should allow access if authenticated and admin', () => {
    guard.canActivate().subscribe(result => {
      expect(result).toBeTrue();
    });
  });

  it('should redirect if not authenticated', () => {
    TestBed.overrideProvider(AuthService, {
      useValue: {
        isAuthenticated$: of(false),
        userRole$: of('admin')
      }
    });

    guard.canActivate().subscribe(result => {
      expect(result).toBeFalse();
      expect(router.url).toBe('/login'); // Asegúrate de que la ruta es correcta
    });
  });

  it('should redirect if not admin', () => {
    TestBed.overrideProvider(AuthService, {
      useValue: {
        isAuthenticated$: of(true),
        userRole$: of('user')
      }
    });

    guard.canActivate().subscribe(result => {
      expect(result).toBeFalse();
      expect(router.url).toBe('/'); // Asegúrate de que la ruta es correcta
    });
  });
});
