import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { map, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {

  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.authService.isAuthenticated$.pipe(
      switchMap(isAuthenticated => {
        if (!isAuthenticated) {
          // Si no está autenticado, redirige al login
          this.router.navigate(['/login']);
          return [false];
        }
        return this.authService.userRole$.pipe(
          map(role => {
            if (role === 'admin') {
              return true; // Permite el acceso si el rol es admin
            } else {
              // Si el rol no es admin, redirige al dashboard del administrador
              this.router.navigate(['/administrador/dashboard']);
              return false;
            }
          })
        );
      })
    );
  }
}
