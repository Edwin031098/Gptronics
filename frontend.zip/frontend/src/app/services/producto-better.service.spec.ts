import { TestBed } from '@angular/core/testing';

import { ProductoBetterService } from './producto-better.service';

describe('ProductoBetterService', () => {
  let service: ProductoBetterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductoBetterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
