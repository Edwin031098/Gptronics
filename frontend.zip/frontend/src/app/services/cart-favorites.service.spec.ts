import { TestBed } from '@angular/core/testing';

import { CartFavoritesService } from './cart-favorites.service';

describe('CartFavoritesService', () => {
  let service: CartFavoritesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CartFavoritesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
