import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CartFavoritesService {
  private cartCountSource = new BehaviorSubject<number>(0);
  private favoritesCountSource = new BehaviorSubject<number>(0);
  private userNameSource = new BehaviorSubject<string>('Usuario');

  cartCount$ = this.cartCountSource.asObservable();
  favoritesCount$ = this.favoritesCountSource.asObservable();
  userName$ = this.userNameSource.asObservable();

  constructor() {}

  updateCartCount(count: number): void {
    this.cartCountSource.next(count);
  }

  updateFavoritesCount(count: number): void {
    this.favoritesCountSource.next(count);
  }

  updateUserName(name: string): void {
    this.userNameSource.next(name);
  }


  getCartCount(): number {
    // Implementa la lógica para obtener el conteo del carrito
    return 5; // Ejemplo estático, reemplázalo con la lógica real
  }

  getFavoritesCount(): number {
    // Implementa la lógica para obtener el conteo de favoritos
    return 3; // Ejemplo estático, reemplázalo con la lógica real
  }

  getUserName(): string {
    // Implementa la lógica para obtener el nombre del usuario
    return 'Juan Pérez'; // Ejemplo estático, reemplázalo con la lógica real
  }
  
}