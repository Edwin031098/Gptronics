import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,Subject  } from 'rxjs';


@Injectable({
  providedIn: 'root'
})


export class CartService {
  private apiUrl = 'http://localhost:8000/api/cart-items'; // Ajusta la URL según tu backend
  private apiUrl2 = 'http://localhost:8000/api/carts'; // Ajusta la URL según tu backend
  private apiUrl3 = 'http://localhost:8000/api/productos'; // Ajusta la URL según tu backend
  private apiUrl4 = 'http://localhost:8000/api/reservations'; // Ajusta la URL según tu backend
  private apiUrl5 = 'http://localhost:8000/api/'; // Ajusta la URL según tu backend


  private cartCountSubject = new Subject<number>(); // Subject para emitir el conteo del carrito
  cartCount$ = this.cartCountSubject.asObservable(); // Observable para escuchar los cambios


  constructor(private http: HttpClient) {}

  // Método para agregar un producto al carrito
  addToCart(cartId: number, productId: number, quantity: number): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}`, { cart_id: cartId, product_id: productId, quantity: quantity });
  }

    // Método para obtener el carrito del usuario
    getCart(userId: number): Observable<any> {
      const url = `${this.apiUrl2}?user_id=${userId}`;
      return this.http.get<any>(`${this.apiUrl2}?user_id=${userId}`);
    }

      // Método para eliminar un producto del carrito
  removeProductFromCart(cartItemId: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${cartItemId}`);
  }
    // Método para actualizar la cantidad de un producto en el carrito
    updateProductQuantity(cartItemId: number, quantity: number): Observable<any> {
      return this.http.put<any>(`${this.apiUrl}/${cartItemId}`, { quantity });
    }

  // Obtiene el conteo de productos en el carrito
  getCartCount(userId: number): Observable<number> {
    return this.http.get<number>(`${this.apiUrl2}/count/${userId}`);
  }


    getCartId(): Observable<any> {
      return this.http.get<any>('http://localhost:8000/api/carts'); // Asegúrate de que esta ruta esté correcta
  }

    // Observa cambios en el conteo del carrito
    getCartCountObservable(): Observable<number> {
      return this.cartCountSubject.asObservable();
    }
  
    // Método para actualizar el conteo del carrito
    updateCartCount(userId: number): void {
      this.getCartCount(userId).subscribe(
        count => {
          this.cartCountSubject.next(count); // Emitir el nuevo conteo
        },
        error => console.error('Error fetching cart count:', error)
      );
    }
  
    reserveProduct(userId: number, products: { pk_producto: number, quantity: number }[]): Observable<any> {
      return this.http.post<any>(`${this.apiUrl4}`, { user_id: userId, products });
    }

    // Método para obtener un producto por ID
    getProductById(productId: string): Observable<any> {
      return this.http.get<any>(`${this.apiUrl3}/${productId}`);
    }

  // Agregar validación del stock
  validateStock(productId: number, quantity: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl5}product/${productId}/stock/${quantity}`);
  }

  reserveCart(userId: number, products: any[]): Observable<any> {
    return this.http.post<any>(`http://localhost:8000/api/reservations/cart_reserve`, { user_id: userId, products });
  }

  clearCart(userId: number): Observable<any> {
    return this.http.post<any>(`${this.apiUrl5}cart/clear`, { user_id: userId });
  }
  
  
}
