import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';

interface RegisterResponse {
  message: string;
}

interface LoginResponse {
  message: string;
  nombre: string;
  role: string; // Agrega el rol en la respuesta de login
  userId: number; // Asegúrate de que `userId` esté en la respuesta
  id: number; // Asegúrate de que `userId` esté en la respuesta

}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = 'http://localhost:8000/api';
  private loggedInUsername: string = "";
  private loggedInUserRole: string = ""; // Agrega una propiedad para el rol del usuario
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  private userRoleSubject = new BehaviorSubject<string | null>(null); // Agrega un BehaviorSubject para el rol
  private userIdSubject = new BehaviorSubject<number | null>(null); // Almacena el ID del usuario

  public isAuthenticated$ = this.isAuthenticatedSubject.asObservable();
  public userRole$ = this.userRoleSubject.asObservable(); // Observable para el rol del usuario

  constructor(private http: HttpClient, private router: Router) {
    if (typeof window !== 'undefined') {
      const savedAuthState = localStorage.getItem('isAuthenticated');
      this.isAuthenticatedSubject.next(savedAuthState === 'true');
      this.loggedInUsername = localStorage.getItem('loggedInUsername') || "";
      this.loggedInUserRole = localStorage.getItem('loggedInUserRole') || "";
      this.userRoleSubject.next(this.loggedInUserRole); // Inicializa el BehaviorSubject con el rol
      this.loadUserIdFromStorage();

    }
  }

  private loadUserIdFromStorage(): void {
    const storedUserId = localStorage.getItem('userId');
    if (storedUserId) {
      this.userIdSubject.next(Number(storedUserId));
    }
  }
  

  register(usuario: any): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>(`${this.baseUrl}/register`, usuario);
  }

  login(usuario: any): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, usuario)
      .pipe(
        tap((response: LoginResponse) => {
          if (response.message === 'Login exitoso') {
            this.loggedInUsername = response.nombre;
            this.loggedInUserRole = response.role; // Guarda el rol del usuario
            this.isAuthenticatedSubject.next(true);
            this.userRoleSubject.next(response.role); // Actualiza el BehaviorSubject con el rol
            const userId = response.userId; 
            console.log(`User ID frsdsdom login response: ${userId}`); // Verifica que el userId se reciba
            this.setUserId(userId); // Configura el userId
  
        
            if (typeof window !== 'undefined') {
              localStorage.setItem('isAuthenticated', 'true');
              localStorage.setItem('loggedInUsername', response.nombre);
              localStorage.setItem('loggedInUserRole', response.role); // Guarda el rol en localStorage
              localStorage.setItem('userId', response.userId.toString()); // Guarda el ID del usuario

            }
            this.router.navigate(['/bienvenido']);
          }
        })
      );
  }

  logout(): void {
    this.loggedInUsername = "";
    this.loggedInUserRole = ""; // Limpia el rol del usuario
    this.isAuthenticatedSubject.next(false);
    this.userRoleSubject.next(null); // Limpia el BehaviorSubject del rol
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('loggedInUsername');
      localStorage.removeItem('loggedInUserRole'); // Remueve el rol de localStorage
    }
    this.router.navigate(['/login']); // Redirige al inicio de sesión
  }

  getLoggedInUsername(): string {
    return this.loggedInUsername;
  }

  getUserRole(): Observable<string | null> {
    // Devuelve el rol del usuario desde el BehaviorSubject
    return this.userRole$; // Devuelve el rol actual del usuario
  }

  isAuthenticated(): boolean {
    return this.isAuthenticatedSubject.value;
  }

  // Método para agregar un proveedor
  addProveedor(proveedor: any): Observable<any> {
    const token = localStorage.getItem('authToken');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
    return this.http.post(`${this.baseUrl}/proveedores`, proveedor, { headers });
  }

  getUserId(): number | null {
    const userId = this.userIdSubject.value;
    console.log(`Getting userId: ${userId}`); // Verifica el ID que se está recuperando
    return userId;
  }


  
  setUserId(userId: number): void {
    console.log(`Setting userId: ${userId}`);
    this.userIdSubject.next(userId);
    localStorage.setItem('userId', userId.toString());
    console.log(`Stored userId in localStorage: ${userId}`);
  }


  
}