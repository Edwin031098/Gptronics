import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})

export class ReservationService {
  private apiUrl = 'http://localhost:8000/api'; // URL base del backend

  constructor(private http: HttpClient) { }

  // Método para obtener las reservas de un usuario
  getUserReservations(userId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/reservations/user/?user_id=${userId}`);
  }

  getReservationDetails(reservationId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservation-details/${reservationId}`);
  }

  
  deleteReservation(reservationId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/reservations/${reservationId}`);
  }
  // Método para obtener todas las reservas
  getReservations(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservations`);
  }
  acceptReservation(id: number, fechaRecoger: string): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/reservations/${id}/accept`, { fecha_recoger: fechaRecoger });
  }
  
  markAsCollected(reservationId: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/reservations/${reservationId}/mark-as-collected`, {});
  }
  // Método para hacer una reserva (opcional)
  // Puedes descomentar este método si también necesitas hacer reservas desde el frontend
  // reserveProduct(userId: number, productId: number, quantity: number): Observable<any> {
  //   return this.http.post<any>(this.apiUrl, { user_id: userId, products: [{ pk_producto: productId, quantity }] });
  // }

}
