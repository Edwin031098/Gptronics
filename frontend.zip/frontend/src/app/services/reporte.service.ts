import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReporteService {
  private apiUrl = 'http://localhost:8000/api/reportes';

  constructor(private http: HttpClient) { }

  getVentasPorDia(date: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/ventas-dia?date=${date}`);
  }


  getVentasPorSemana(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/ventas-semana`);
  }


  getProductoMasVendido(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/producto-mas-vendido`);
  }

  getGananciaPorMes(month: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/ganancia-mes?month=${month}`);
  }

  getGananciaPorDia(date: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/ganancia-dia?date=${date}`);
  }

  getProductosConStockBajo(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/productos-stock-bajo`);
  }

  getGastos(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/gastos`);
  }
}
