import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl = 'http://localhost:8000/api/productos'; // Asegúrate de que la URL sea correcta
  private baseUrl2 = 'http://localhost:8000/api'; // Asegúrate de que la URL sea correcta

  constructor(private http: HttpClient) { }

  // Método para obtener todos los productos
  getProducts(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }
  
  getProduct(id: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }

  createProduct(product: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, product);
  }

  updateProduct(id: String, productData: any) {
    return this.http.put(`${this.baseUrl}/${id}`, productData);
  }


  deleteProduct(id: number): Observable<any> { // Cambiar el tipo a number
    return this.http.delete<any>(`${this.baseUrl}/${id}`);
  }

  
  increaseProductStock(id: number, quantity: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/${id}/stock/increase`, { quantity });
  }
  
  decreaseProductStock(id: number, quantity: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/${id}/stock/decrease`, { quantity });
  }

// product.service.ts
changeImage(productId: string, imageData: FormData): Observable<any> {
  const url = `${this.baseUrl}/change-image/${productId}`;
  return this.http.post(url, imageData);
}

updateProductImage(productId: number, imageFile: File): Observable<any> {
  const formData = new FormData();
  formData.append('imagen', imageFile);

  return this.http.post(`${this.baseUrl}/${productId}/update-image`, formData);
}

getCategories(): Observable<any[]> {
  return this.http.get<any[]>(`${this.baseUrl2}/categorias`);
}

getBrands(): Observable<any[]> {
  return this.http.get<any[]>(`${this.baseUrl2}/marcas`);
}

  
  
}
