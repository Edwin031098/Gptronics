import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';
import { Observable, of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { RutaService } from './ruta.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'frontend';
  isLoggedIn$: Observable<boolean>;
  isAdmin$: Observable<boolean>;
  showNavbarClient$: Observable<boolean>;
  showNavbarAdmin$: Observable<boolean>;

  constructor(private rutaService: RutaService, private router: Router, public authService: AuthService) { }

  ngOnInit(): void {
    this.isLoggedIn$ = this.authService.isAuthenticated$;

    // Usar un observable para isAdmin
    this.isAdmin$ = this.authService.getUserRole().pipe(
      map(role => role === 'admin')
    );

    // Manejar el caso cuando isAdmin$ puede ser null
    this.showNavbarClient$ = this.isLoggedIn$.pipe(
      switchMap(isLoggedIn =>
        this.isAdmin$.pipe(
          map(isAdmin => !isLoggedIn || !isAdmin)
        )
      )
    );

    // Manejar el caso cuando isAdmin$ puede ser null
    this.showNavbarAdmin$ = this.isLoggedIn$.pipe(
      switchMap(isLoggedIn =>
        this.isAdmin$.pipe(
          map(isAdmin => isLoggedIn && isAdmin)
        )
      )
    );
  }

  navigateTo(accion: string): void {
    this.rutaService.getUrl(accion).subscribe(
      response => {
        if (response.url === '/') {
          this.router.navigate(['/']);
        } else if (response.url) {
          this.router.navigate([response.url]);
        } else {
          this.router.navigate(['/']);
        }
      },
      error => {
        console.error('Error fetching URL:', error);
        this.router.navigate(['/']);
      }
    );
  }
}
