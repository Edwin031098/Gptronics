import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isLoggedIn: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      correo: ['', [Validators.required, Validators.email]],
      clave: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    // Opcional: Si ya está autenticado, redirige al rol correspondiente
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      if (isAuthenticated) {
        this.authService.getUserRole().subscribe(role => {
          if (role === 'admin') {
            this.router.navigate(['/administrador/dashboard']);
          } else {
            this.router.navigate(['/bienvenido']);
          }
        });
      }
    });
  }
  
  login(): void {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe(
        response => {
          // Muestra un mensaje de éxito y luego redirige al usuario
          Swal.fire({
            title: 'Éxito',
            text: response.message,
            icon: 'success',
            confirmButtonText: 'OK'
          }).then(() => {
            this.isLoggedIn = true; // Marca como autenticado
            this.authService.getUserRole().subscribe(role => {
              if (role === 'admin') {
                this.router.navigate(['/administrador/dashboard']); // Redirige al dashboard del admin
              } else {
                this.router.navigate(['/bienvenido']); // Redirige a la página de bienvenida
              }
            });
          });
        },
        error => {
          console.error(error);
          // Muestra un mensaje de error
          Swal.fire({
            title: 'Error',
            text: 'Error al iniciar sesión',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }
      );
    } else {
      // Muestra una advertencia si el formulario no es válido
      Swal.fire({
        title: 'Advertencia',
        text: 'Por favor, completa el formulario correctamente',
        icon: 'warning',
        confirmButtonText: 'OK'
      });
    }
  }
}
