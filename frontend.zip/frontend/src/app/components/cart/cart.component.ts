import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service'; // Ajusta la ruta según tu estructura de archivos
import { AuthService } from '../../services/auth.service'; // Ajusta la ruta según tu estructura de archivos
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  cartItems: any[] = []; // Para almacenar los artículos del carrito
  cartTotal: number = 0; // Para almacenar el total del carrito
  userPhoneNumber: string = ''; // Para almacenar el número de teléfono del usuario

  constructor(
    private cartService: CartService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart(); // Cargar el carrito al inicializar el componente
    
  }


  loadCart(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.getCart(userId).subscribe(
        cart => {
          this.cartItems = cart.items;
          this.calculateTotal();
        },
        error => {
          console.error('Error loading cart:', error);
        }
      );
    }
  }


  calculateTotal(): void {
    this.cartItems = this.cartItems.map(item => ({
      ...item,
      totalPrice: item.quantity * parseFloat(item.product?.precio || '0') // Asegúrate de que `product` no sea undefined
    }));
    
    this.cartTotal = this.cartItems.reduce((acc, item) => acc + item.totalPrice, 0);
  }

  getProductImageUrl(imagePath: string | null): string {
    const baseUrl = 'http://127.0.0.1:8000/storage/';
    return imagePath ? baseUrl + imagePath : 'assets/default-image.jpg'; // Ruta a una imagen por defecto si no hay imagen
  }




  increaseQuantity(item: any): void {
    const userId = this.authService.getUserId();
    if (userId) {

      this.cartService.validateStock(item.product.pk_producto, item.quantity + 1).subscribe(
        
        response => {
          console.log('Product ID:', item.product.pk_producto);

          if (response.isAvailable) {
            this.cartService.updateProductQuantity(item.id, item.quantity + 1).subscribe(
              () => {
                item.quantity += 1;
                this.calculateTotal();
              },
              error => {
                console.error('Error increasing quantity:', error);
              }
            );
          } else {
            Swal.fire({
              title: 'Stock insuficiente',
              text: 'No hay suficiente stock para aumentar la cantidad.',
              icon: 'warning',
              confirmButtonText: 'Aceptar'
            });
          }
        },
        error => {
          console.error('Error validating stock:', error);
        }
      );
    }
  }

  decreaseQuantity(item: any): void {
    if (item.quantity > 1) { // Evita que la cantidad sea menor a 1
      const userId = this.authService.getUserId();
      if (userId) {
        this.cartService.updateProductQuantity(item.id, item.quantity - 1).subscribe(
          response => {
            item.quantity -= 1;
            this.calculateTotal();
            const userId = this.authService.getUserId();
            if (userId) {
              this.cartService.updateCartCount(userId); // Actualiza el conteo después de agregar al carrito
            }
          },
          error => {
            console.error('Error decreasing quantity:', error);
          }
        );
      }
    }
  }

  removeFromCart(cartItemId: number): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.removeProductFromCart(cartItemId).subscribe(
        response => {
          this.cartItems = this.cartItems.filter(item => item.id !== cartItemId);
          this.calculateTotal();
          const userId = this.authService.getUserId();
          if (userId) {
            this.cartService.updateCartCount(userId); // Actualiza el conteo después de agregar al carrito
          }
          Swal.fire({
            title: 'Producto eliminado',
            text: 'El producto ha sido eliminado del carrito.',
            icon: 'success',
            confirmButtonText: 'Aceptar'
          });
        },
        error => {
          console.error('Error removing product from cart:', error);
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al eliminar el producto del carrito.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      );
    }
  }


  reserveCart(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      const products = this.cartItems.map(item => ({
        pk_producto: item.product.pk_producto,
        quantity: item.quantity
      }));

      this.cartService.reserveCart(userId, products).subscribe(
        response => {
          Swal.fire({
            title: '¡Reserva Exitosa!',
            text: `Tu reserva ha sido realizada con éxito. Puedes recoger tus productos en nuestra tienda: Zaragoza #152, Colonia Centro, Local Azul con Blanco de Nombre GPtronics, a media cuadra del teatro.`,
            icon: 'success',
            confirmButtonText: 'Aceptar'
          }).then(() => {
            if (this.userPhoneNumber) {
              this.sendLocationViaWhatsApp(this.userPhoneNumber);
            }
            this.clearCart(); // Limpiar el carrito después de la reserva

          });
        },
          
        error => {
          console.error('Error reserving cart:', error);
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al apartar los productos.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      );
    }
  }

  proceedToReserve(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.reserveCart(userId, this.cartItems.map(item => ({
        pk_producto: item.product.id,
        quantity: item.quantity
      }))).subscribe(
        response => {
          Swal.fire({
            title: '¡Reserva Exitosa!',
            text: `Tu reserva ha sido realizada con éxito. Puedes recoger tus productos en nuestra tienda: Zaragoza #152, Colonia Centro, Local Azul con Blanco de Nombre GPtronics, a media cuadra del teatro.`,
            icon: 'success',
            confirmButtonText: 'Aceptar'
          }).then(() => {
            if (this.userPhoneNumber) {
              this.sendLocationViaWhatsApp(this.userPhoneNumber);
            }
            this.clearCart(); // Limpiar el carrito después de la reserva

            this.cartItems = []; // Limpiar el carrito
            this.cartTotal = 0;
          });
        },
        error => {
          console.error('Error reservando el carrito:', error);
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al realizar la reserva.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      );
    }
  }
  sendLocationViaWhatsApp(phoneNumber: string): void {
    const locationUrl = `https://api.whatsapp.com/send?phone=3112687341&text=Hola!%20Tu%20reserva%20ha%20sido%20realizada%20con%20éxito.%20Puedes%20recoger%20tus%20productos%20en%20nuestra%20tienda:%20Zaragoza%20%23152,%20Colonia%20Centro,%20Local%20Azul%20con%20Blanco%20de%20Nombre%20GPtronics,%20a%20media%20cuadra%20del%20teatro.`;
    window.open(locationUrl, '_blank');
  }

  clearCart(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.clearCart(userId).subscribe(
        () => {
          this.cartItems = []; // Limpiar el carrito en el frontend
          this.cartTotal = 0; // Reiniciar el total del carrito
        },
        error => {
          console.error('Error clearing cart:', error);
        }
      );
    }

  }
}