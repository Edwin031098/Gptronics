import { Component, OnInit  } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service'; // Asegúrate de que la ruta sea correcta
import { RutaService } from '../../ruta.service';
import { CartFavoritesService } from '../../services/cart-favorites.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-navbar-client',
  templateUrl: './navbar-client.component.html',
  styleUrl: './navbar-client.component.scss'
})
export class NavbarClientComponent implements OnInit  {
  cartCount: number = 0;
  favoritesCount: number = 0;
  userName: string = 'Usuario';
  cartItems: any[] = []; // Para almacenar los artículos del carrito
  cartVisible: boolean = false; // Para controlar la visibilidad del dropdown del carrito
  private cartCountSubscription: Subscription;
  userRole: string | null = null; // Añade una propiedad para el rol del usuario

  constructor(public authService: AuthService,private cartFavoritesService: CartFavoritesService,private cartService: CartService) { }
  
  
  ngOnInit(): void {
    this.cartFavoritesService.cartCount$.subscribe(count => this.cartCount = count);
    this.cartFavoritesService.favoritesCount$.subscribe(count => this.favoritesCount = count);
    
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      if (isAuthenticated) {
        this.userName = this.authService.getLoggedInUsername();
        this.authService.getUserRole().subscribe(role => {
          this.userRole = role; // Obtener el rol del usuario desde el Observable
        });
      } else {
        this.userName = 'Usuario';
        this.userRole = null; // Establecer el rol a null si no está autenticado

      }
    });
    this.loadCart(); // Cargar el carrito al inicializar el componente
    this.updateCartCount();
    this.cartCountSubscription = this.cartService.getCartCountObservable().subscribe(
      count => {
        this.cartCount = count; // Actualiza el contador
      },
      error => {
        console.error('Error receiving cart count:', error);
      }
    );

    this.loadCartCount(); // Cargar el conteo inicial del carrito
  }



  loadCart(): void {
    const userId = this.authService.getUserId(); // Obtener el ID del usuario desde el servicio de autenticación
    if (userId !== null) {
      this.cartService.getCart(userId).subscribe(
        (cart) => {
          this.cartItems = cart.items; // Asignar los artículos del carrito
          this.cartCount = this.cartItems.length; // Contar los artículos en el carrito
        },
        (error) => {
          console.error('Error loading cart:', error); // Manejar errores al cargar el carrito
        }
      );
    }
  }

  toggleCart(): void {
    this.cartVisible = !this.cartVisible; // Alternar la visibilidad del carrito
    if (this.cartVisible) {
      this.loadCart(); // Opcional: cargar el carrito al mostrarlo
    }
  }


  updateCartCount(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.getCartCount(userId).subscribe(
        count => {
          this.cartCount = count;

        },
        error => {
          console.error('Error fetching cart count:', error);
        }
      );
    } else {
      console.warn('No user ID found. Cannot update cart count.');
    }
  }

  openCart(): void {
    // Implementa la lógica para abrir el modal del carrito o redirigir a la página del carrito
    console.log('Abrir carrito');
  }

  openFavorites(): void {
    // Implementa la lógica para abrir el modal de favoritos o redirigir a la página de favoritos
    console.log('Abrir favoritos');
  }

  logout() {
    this.authService.logout();
  }

  ngOnDestroy(): void {
    if (this.cartCountSubscription) {
      this.cartCountSubscription.unsubscribe(); // Limpiar suscripción al destruir el componente
    }
  }

  loadCartCount(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.cartService.updateCartCount(userId); // Actualiza el conteo del carrito
    }
  }
}
