import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service'; // Asegúrate de que la ruta sea correcta

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss'
})
export class ProductsComponent implements OnInit {
  products: any[] = [];
  baseImageUrl: string = 'http://127.0.0.1:8000/storage/'; // URL base para las imágenes

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(data => {
      this.products = data;
    });
  }
  getImageUrl(imagePath: string): string {
    return `${this.baseImageUrl}${imagePath}`;
  }
}