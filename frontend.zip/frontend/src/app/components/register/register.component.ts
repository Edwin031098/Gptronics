import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router'; // Importa Router

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) { // Inyecta Router
    this.registerForm = this.fb.group({
      correo: ['', [Validators.required, Validators.email]],
      clave: ['', [Validators.required, Validators.minLength(6)]],
      nombre: ['', [Validators.required]],
      telefono: ['', Validators.required], // Asegúrate de que este campo esté aquí

    });
  }

  register() {
    if (this.registerForm.valid) {
      this.authService.register(this.registerForm.value).subscribe(
        response => {
          Swal.fire({
            title: 'Registro Exitoso',
            text: response.message,
            icon: 'success',
            confirmButtonText: 'Aceptar'
          }).then(() => {
            this.router.navigate(['/login']); // Redirige al login después de aceptar el mensaje
          });
        },
        error => {
          console.error(error);
          Swal.fire({
            title: 'Error',
            text: 'No se pudo completar el registro',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      );
    } else {
      Swal.fire({
        title: 'Advertencia',
        text: 'Por favor, completa el formulario correctamente',
        icon: 'warning',
        confirmButtonText: 'Aceptar'
      });
    }
  }
}
