import { Component, OnInit, NgModule , ViewChild, TemplateRef } from '@angular/core';
import { AuthService } from '../../services/auth.service'; // Ajusta la ruta según la ubicación de AuthService
import { ProductService } from '../../services/product.service'; // Ajusta la ruta según la ubicación del servicio
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap'; // Asegúrate de instalar y configurar NgbModal
import { BrowserModule } from '@angular/platform-browser';
import { CartFavoritesService } from '../../services/cart-favorites.service';
import { CartService } from '../../services/cart.service'; // Servicio para manejar el carrito

@Component({
  selector: 'app-bienvenido',
  templateUrl: './bienvenido.component.html',
  styleUrls: ['./bienvenido.component.css']
})


export class BienvenidoComponent implements OnInit {

  @ViewChild('productDetailModal') productDetailModal!: TemplateRef<any>;

  loggedInUsername: string = "";
  products: any[] = [];
  filteredProducts: any[] = [];
  baseImageUrl: string = 'http://127.0.0.1:8000/storage/'; // URL base para las imágenes
  selectedProduct: any; // Variable para el producto seleccionado
  cartCount: number = 0; // Contador de productos en el carrito
  favoritesCount: number = 0; // Contador de productos en favoritos
  userName: string = 'Usuario'; // Nombre del usuario
  cartId: number | null = null;
  userId: number | null = null; // Define la propiedad userId
  searchTerm: string = '';
  selectedCategories: Set<number> = new Set();
  selectedBrands: Set<number> = new Set();
  categories: any[] = []; // Declarar categories
  brands: any[] = []; // Declarar brands


  constructor(public authService: AuthService,
    private cartService: CartService, 
    private router: Router, 
    private productService: ProductService, 
    private modalService: NgbModal, 
    private cartFavoritesService: CartFavoritesService) { }

  ngOnInit(): void {
    this.loggedInUsername = this.authService.getLoggedInUsername();
    this.loadProducts();
    this.loadCategories();
    this.loadBrands();
    this.cartFavoritesService.cartCount$.subscribe(count => this.cartCount = count);
    this.cartFavoritesService.favoritesCount$.subscribe(count => this.favoritesCount = count);
    this.cartFavoritesService.userName$.subscribe(name => this.userName = name);
    this.loadUserId();
    this.loadCart();

  }


  loadUserId(): void {
    this.userId = this.authService.getUserId();
  }



  loadCart(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      console.log('Fetching cart for user ID:', userId); // Verifica el ID de usuario al hacer la solicitud

      this.cartService.getCart(userId).subscribe(
        cart => {
          this.cartId = cart.id; // Almacena el ID del carrito
        },
        error => {
          console.error('Error loading cart:', error); // Verifica cualquier error al cargar el carrito
        }
      );
    } else {
      console.error('User ID not available');
    }
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe(
      (data: any[]) => {
        this.products = data.map(product => ({
          ...product,
          imagen: this.baseImageUrl + product.imagen
        }));
        this.filteredProducts = this.products; // Inicialmente, los productos filtrados son todos los productos

      },
      error => {
        console.error('Error fetching products', error);
      }
    );
  }

  loadCategories(): void {
    // Aquí debes implementar la lógica para cargar las categorías desde el servicio
    this.productService.getCategories().subscribe(
      (data: any[]) => {
        this.categories = data;
      },
      error => {
        console.error('Error fetching categories', error);
      }
    );
  }

  loadBrands(): void {
    // Aquí debes implementar la lógica para cargar las marcas desde el servicio
    this.productService.getBrands().subscribe(
      (data: any[]) => {
        this.brands = data;
      },
      error => {
        console.error('Error fetching brands', error);
      }
    );
  }

  onCategoryChange(event: any): void {  
    const categoryId = +event.target.value;
    if (event.target.checked) {
      this.selectedCategories.add(categoryId);
    } else {
      this.selectedCategories.delete(categoryId);
    }
    this.filterProducts();
  }

  onBrandChange(event: any): void {
    const brandId = +event.target.value;
    if (event.target.checked) {
      this.selectedBrands.add(brandId);
    } else {
      this.selectedBrands.delete(brandId);
    }
    this.filterProducts();
  }

  filterProducts(): void {
    console.log('Filtering products with categories:', this.selectedCategories);
    console.log('Filtering products with brands:', this.selectedBrands);
    console.log('Search term:', this.searchTerm);
  
    this.filteredProducts = this.products.filter(product => {
      console.log('Checking product:', product);
  
      // Verifica si el producto cumple con los filtros de categoría y marca
      const categoryMatch = this.selectedCategories.size === 0 || this.selectedCategories.has(product.FK_categoria);
      const brandMatch = this.selectedBrands.size === 0 || this.selectedBrands.has(product.FK_marca);
  
      // Verifica si el producto cumple con el término de búsqueda
      const searchTermMatch = product.nombre.toLowerCase().includes(this.searchTerm.toLowerCase());
  
      console.log('Category match:', categoryMatch);
      console.log('Brand match:', brandMatch);
      console.log('Search term match:', searchTermMatch);
  
      // El producto debe cumplir con los filtros de categoría, marca y búsqueda
      return categoryMatch && brandMatch && searchTermMatch;
    });
  
    console.log('Filtered products:', this.filteredProducts);
  }
  

 
  logout(): void {
    Swal.fire({
      title: '¿Estás seguro?',
      text: 'Deseas cerrar sesión',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, cerrar sesión',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        this.authService.logout(); // Llama al método de logout
        Swal.fire('¡Cerrado!', 'Has cerrado sesión correctamente.', 'success')
          .then(() => {
            // Redirige a la página de inicio de sesión y luego recarga la página
            this.router.navigate(['/bienvenido']).then(() => {
              window.location.reload(); // Forza la recarga de la página
            });
          });
      }
    });
  }

  openCart(): void {
    // Implementa la lógica para abrir el modal del carrito de compras
  }

  openFavorites(): void {
    // Implementa la lógica para abrir el modal de favoritos
  }



  openProductDetailModal(product: any): void {
    this.selectedProduct = product;
    this.modalService.open(this.productDetailModal, { size: 'lg' }); // Tamaño del modal opcional
  }

  addToCart(product: any): void {
    if (this.authService.isAuthenticated()) {
      if (this.cartId === null) {
        console.error('No cart ID available');
        return;
      }
  
      const productId = product.pk_producto;
      const quantity = 1;
  
      // Log para verificar que los valores están definidos
  
      this.cartService.addToCart(this.cartId, productId, quantity).subscribe(
        response => {
          // Confirmación de que el artículo se ha agregado
          Swal.fire({
            title: 'Artículo agregado',
            text: 'El artículo ha sido agregado a tu carrito con éxito.',
            icon: 'success',
            confirmButtonText: 'Aceptar'
          });


          const userId = this.authService.getUserId();
        if (userId) {
          this.cartService.updateCartCount(userId); // Actualiza el conteo después de agregar al carrito
        }
        },
        error => {
          console.error('Error adding product to cart:', error);
          Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al agregar el artículo al carrito.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      );
    } else {
      Swal.fire({
        title: '¡Necesitas iniciar sesión!',
        text: 'Debes iniciar sesión para agregar productos al carrito.',
        icon: 'info',
        confirmButtonText: 'Ir al Login'
      }).then(() => {
        this.router.navigate(['/login']);
      });
    }
  }
  
  
  getCartId(): number {
    // Implementa la lógica para obtener el ID del carrito del usuario autenticado
    // Puedes almacenarlo en un servicio o en el estado del componente
    return 1; // Ejemplo estático
  }


  addToFavorites(product: any): void {
    if (this.authService.isAuthenticated()) {
      // Lógica para agregar a favoritos
      console.log('Producto agregado a favoritos:', product);
    } else {
      Swal.fire({
        title: '¡Necesitas iniciar sesión!',
        text: 'Debes iniciar sesión para agregar productos a favoritos.',
        icon: 'info',
        confirmButtonText: 'Ir al Login'
      }).then(() => {
        this.router.navigate(['/login']);
      });
    }
  }

  reserveProduct(product: any): void {
    if (this.authService.isAuthenticated()) {
      // Redirige a la página de detalles del apartado con el producto seleccionado
      this.router.navigate(['/reserve', product.pk_producto]);
    } else {
      Swal.fire({
        title: '¡Necesitas iniciar sesión!',
        text: 'Debes iniciar sesión para apartar productos.',
        icon: 'info',
        confirmButtonText: 'Ir al Login'
      }).then(() => {
        this.router.navigate(['/login']);
      });
    }
  }


}