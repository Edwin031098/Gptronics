import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrls: ['./admin-orders.component.scss']
})
export class AdminOrdersComponent implements OnInit {
  orders: any[] = [];
  private baseUrl: string = 'http://localhost:8000/api';

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    this.http.get<any[]>(`${this.baseUrl}/orders`).subscribe(
      data => this.orders = data,
      error => console.error('Error loading orders:', error)
    );
  }

  acceptOrder(orderId: number): void {
    this.http.patch<any>(`${this.baseUrl}/orders/${orderId}`, { estado: 'aceptado' }).subscribe(
      () => {
        alert('Order accepted');
        this.loadOrders();
      },
      error => console.error('Error accepting order:', error)
    );
  }

  deleteOrder(orderId: number): void {
    this.http.delete<any>(`${this.baseUrl}/orders/${orderId}`).subscribe(
      () => {
        alert('Order deleted');
        this.loadOrders();
      },
      error => console.error('Error deleting order:', error)
    );
  }
}
