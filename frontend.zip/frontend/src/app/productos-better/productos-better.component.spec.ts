import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductosBetterComponent } from './productos-better.component';

describe('ProductosBetterComponent', () => {
  let component: ProductosBetterComponent;
  let fixture: ComponentFixture<ProductosBetterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductosBetterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductosBetterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
