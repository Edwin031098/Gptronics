import { Component, OnInit } from '@angular/core';
import { ProductoBetterService } from '../services/producto-better.service';

@Component({
  selector: 'app-productos-better',
  templateUrl: './productos-better.component.html',
  styleUrls: ['./productos-better.component.scss']
})
export class ProductosBetterComponent implements OnInit {
  productos: any[] = [];
  producto: any = { codigo: '', nombre: '', precio: 0, categoria: '', estado: 1 };
  categorias: string[] = ['Casita', 'Ofertas', 'Practimuebles', 'Cocina', 'Gurmy', 'Recamara', 'Bienestar', 'Baño', 'Higiene y Limpieza', 'Hogar', 'Contigo', 'BetterLocura']; // Ejemplo de categorías predefinidas

  constructor(private productoService: ProductoBetterService) { }

  ngOnInit(): void {
    this.loadProductos();
  }

  loadProductos(): void {
    this.productoService.getAllProductos().subscribe(data => {
      this.productos = data;
    });
  }

  saveProducto(): void {
    if (this.producto.id) {
      this.productoService.updateProducto(this.producto.id, this.producto).subscribe(() => {
        this.loadProductos();
        this.resetProducto();
      });
    } else {
      this.productoService.createProducto(this.producto).subscribe(() => {
        this.loadProductos();
        this.resetProducto();
      });
    }
  }

  editProducto(producto: any): void {
    this.producto = { ...producto };
  }


  deleteProducto(id: number): void {
    this.productoService.deleteProducto(id).subscribe(() => {
      this.loadProductos();
    });
  }


  modifyEstado(producto: any): void {
    producto.estado = producto.estado === 1 ? 0 : 1; // Alternar estado entre 1 y 0
    this.productoService.updateProducto(producto.id, producto).subscribe(() => {
      this.loadProductos();
    });
  }


  private resetProducto(): void {
    this.producto = { codigo: '', nombre: '', precio: 0, categoria: '', estado: 1 }; // Resetear formulario
  }
}
