import { Component,OnInit  } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CartService } from '../services/cart.service'; // Ajusta la ruta si es necesario
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrl: './reserve.component.scss'
})
export class ReserveComponent implements OnInit {
  product: any; // Para almacenar el producto
  stockAvailable: number = 0; // Para almacenar el stock disponible
  quantity: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private cartService: CartService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadProduct(); // Cargar el producto al inicializar el componente
  }

  loadProduct(): void {
    const productId = this.route.snapshot.paramMap.get('id');
    if (productId) {
      this.cartService.getProductById(productId).subscribe(
        product => {
          this.product = product;
          this.stockAvailable = product.stock; // Asegúrate de que el campo de stock esté correcto
        },
        error => {
          console.error('Error loading product:', error);
        }
      );
    } else {
      console.error('Product ID is undefined');
      // Maneja el caso en que el ID del producto es indefinido
    }
  }
  

  confirmReservation(): void {
    if (this.quantity && this.quantity > 0 && this.quantity <= this.stockAvailable) {
      // Lógica para confirmar la reserva
      console.log('Reserva confirmada:', {
        productId: this.product.pk_producto,
        quantity: this.quantity
      });
  
      const userId = this.authService.getUserId();
      if (userId) {
        // Enviar un array de productos con la cantidad
        this.cartService.reserveProduct(userId, [
          { pk_producto: this.product.pk_producto, quantity: this.quantity }
        ]).subscribe(
          response => {
            Swal.fire({
              title: 'Reserva confirmada',
              text: 'Tu producto ha sido apartado exitosamente.',
              icon: 'success',
              confirmButtonText: 'Aceptar'
            }).then(() => {
              this.router.navigate(['/']); // Redirige al usuario a la página principal o a otra página
            });
          },
          error => {
            console.error('Error reservando producto:', error);
            Swal.fire({
              title: 'Error',
              text: 'Hubo un problema al apartar el producto.',
              icon: 'error',
              confirmButtonText: 'Aceptar'
            });
          }
        );
      } else {
        Swal.fire({
          title: '¡Necesitas iniciar sesión!',
          text: 'Debes iniciar sesión para apartar productos.',
          icon: 'info',
          confirmButtonText: 'Ir al Login'
        }).then(() => {
          this.router.navigate(['/login']);
        });
      }
    } else {
      Swal.fire({
        title: 'Producto agotado',
        text: 'El producto no está disponible en stock.',
        icon: 'warning',
        confirmButtonText: 'Aceptar'
      });
    }
  }
  
}