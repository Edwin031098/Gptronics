import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './dashboard/dashboard.component';
import { AdminGuard } from '../guards/admin.guard';
import { ProveedorComponent } from './proveedor2/proveedor2.component'; // Usa el nombre correcto del componente
import { CategoriaComponent } from './categoria/categoria.component';
import { ReservationManagementComponent } from './reservation-management/reservation-management.component';

const routes: Routes = [
  { path: 'dashboard', component: AdminDashboardComponent, canActivate: [AdminGuard] },
  { path: 'proveedor', component: ProveedorComponent, canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
  { path: 'categorias', component: CategoriaComponent, canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
  { path: 'reservations', component: ReservationManagementComponent, canActivate: [AdminGuard] },
// Usa el nombre correcto del componente
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
