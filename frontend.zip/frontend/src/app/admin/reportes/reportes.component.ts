import { Component, OnInit } from '@angular/core';
import { ReporteService } from '../../services/reporte.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  styleUrls: ['./reportes.component.scss']
})
export class ReportesComponent implements OnInit {
  ventasPorDia: any[] = [];
  ventasPorSemana: any = {};  // Cambia de any[] a {}
  productoMasVendido: any[] = [];
  gananciaPorMes: any[] = [];
  gananciaPorDia: any = {}; // Cambiar a objeto
  productosConStockBajo: any[] = [];
  gastos: any[] = [];
  total_ventas: any[] = [];
  constructor(private reporteService: ReporteService) {}

  ngOnInit(): void {
    this.loadReportes();

    const today = new Date().toISOString().split('T')[0];
    this.reporteService.getVentasPorDia(today).subscribe(data => {
      console.log('Ventas por Día:', data); // Verifica si los datos se reciben
      this.ventasPorDia = [{
        fecha: today,
        total: parseFloat(data.total_ventas)
      }];
    });
  }
  

  
  loadReportes(): void {
    const today = new Date().toISOString().split('T')[0];
    const month = today.slice(0, 7); // 'YYYY-MM'
    this.reporteService.getVentasPorSemana().subscribe(data => {
      console.log('Ventas por Semana:', data);
      this.ventasPorSemana = data;
    });

    this.reporteService.getVentasPorSemana().subscribe(data => {
      console.log('Ventas por Semana:', data);
      this.ventasPorSemana = data;
    });
    this.reporteService.getVentasPorDia(today).subscribe(data => {
      console.log('Ventas por Día en loadReportes:', data); // Verifica si los datos se reciben
      this.ventasPorDia = data;
    });
    this.reporteService.getVentasPorSemana().subscribe(data => {
      console.log('Ventas por Semana:', data);
      this.ventasPorSemana = data;
    });
    this.reporteService.getProductoMasVendido().subscribe(data => {
      console.log('Producto Más Vendido:', data); // Verifica si los datos se reciben
      this.productoMasVendido = [{
        nombre: data.producto.nombre,
        cantidad_vendida: data.cantidad_vendida
      }];
    });
    this.reporteService.getGananciaPorMes(month).subscribe(data => {
      console.log('Ganancia por Mes:', data); // Verifica si los datos se reciben
      this.gananciaPorMes = data;
    });
      this.reporteService.getGananciaPorDia(today).subscribe(data => {
        console.log('Ganancia por Día:', data); // Verifica si los datos se reciben
        this.gananciaPorDia = data;
      });
    this.reporteService.getProductosConStockBajo().subscribe(data => {
      console.log('Productos con Stock Bajo:', data); // Verifica si los datos se reciben
      this.productosConStockBajo = data;
    });
    this.reporteService.getGastos().subscribe(data => {
      console.log('Gastos:', data);
      this.gastos = data; // Asignar el arreglo de gastos recibido
    });
  }
  
  
  
}
