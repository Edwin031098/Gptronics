import { Component, OnInit,TemplateRef, ViewChild   } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../services/product.service'; // Ajusta la ruta si es necesario
import Swal from 'sweetalert2'; // Importa SweetAlert2
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { CategoriaService } from '../../services/categoria.service';
import { MarcaService } from '../../services/marca.service';
import { ProveedorService } from '../../services/proveedor.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  productForm: FormGroup;
  productFormEdit: FormGroup; // Para editar productos
  currentImageUrl: string | ArrayBuffer | null = null;
  productId: string | null = null;
  product: any;
  categorias: any[] = [];
  marcas: any[] = [];
  proveedores: any[] = [];
  products: any[] = []; // <-- Agrega esta propiedad
  selectedFile: File | null = null;
  @ViewChild('editProductModal') editProductModal: TemplateRef<any> | null = null;
  isEditMode: boolean = false; // Determina si está en modo de edición o visualización

  @ViewChild('changeImageModal') changeImageModal: TemplateRef<any> | null = null;
  selectedImageFile: File | null = null;
  productToChangeImageId: number | null = null;

  modalRef: NgbModalRef | undefined; // Referencia al modal

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private categoriaService: CategoriaService,
    private marcaService: MarcaService,
    private proveedorService: ProveedorService,
    private router: Router,
    private route: ActivatedRoute,  
    private modalService: NgbModal

  ) {
    this.productForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.maxLength(50)]],
      caracteristicas: ['', [Validators.required, Validators.maxLength(256)]],
      descripcion: ['', [Validators.required, Validators.maxLength(256)]],
      precio: ['', [Validators.required, Validators.min(0)]],
      stock: ['', [Validators.required, Validators.min(0)]],
      stock_minimo: ['', [Validators.required, Validators.min(0)]],
      FK_categoria: ['', Validators.required],
      FK_proveedor: ['', Validators.required],
      FK_marca: ['', Validators.required],
      precio_costo: ['', [Validators.required, Validators.min(0)]],
      precio_mayoreo: ['', [Validators.required, Validators.min(0)]],
      precio_oferta: ['', [Validators.required, Validators.min(0)]],
      cantidad_producto_mayoreo: ['', [Validators.required, Validators.min(0)]],
      estado: ['', [Validators.required, Validators.min(0)]],
      fecha_creacion: ['', Validators.required],
      codigo_barras: ['', Validators.required], // Nuevo campo
      imagen: ['']

    });
        // Formulario para editar productos
        this.productFormEdit = this.fb.group({
          nombre: [''],
          caracteristicas: [''],
          descripcion: [''],
          precio: [''],
          stock: [''],
          stock_minimo: [''],
          precio_costo: [''],
          precio_mayoreo: [''],
          precio_oferta: [''],
          cantidad_producto_mayoreo: [''],
          estado: [''],
          codigo_barras: [''],
        });
        
  }

  onImageFileChange(event: any): void {
    if (event.target.files.length > 0) {
      this.selectedImageFile = event.target.files[0];
    }
  }
  open(content: TemplateRef<any>) {
    this.modalService.open(content, { ariaLabelledBy: 'productModalLabel' });
  }

  
  changeImage(): void {
    if (this.productToChangeImageId && this.selectedImageFile) {
      const imageData = new FormData();
      imageData.append('imagen', this.selectedImageFile, this.selectedImageFile.name);
  
      // Convierte productToChangeImageId a string si es necesario
      const productIdAsString = this.productToChangeImageId.toString();
  
      this.productService.changeImage(productIdAsString, imageData).subscribe(
        () => {
          Swal.fire({
            icon: 'success',
            title: '¡Imagen cambiada!',
            text: 'La imagen del producto se ha cambiado exitosamente.',
          }).then(() => {
            this.loadProducts();
            this.modalService.dismissAll(); // Cierra el modal
          });
        },
        (error) => {
          console.error('Error al cambiar la imagen del producto', error);
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al cambiar la imagen del producto.',
          });
        }
      );
    }
  }
  
  



  ngOnInit(): void {
    console.log('ngOnInit llamado');
    this.productId = this.route.snapshot.paramMap.get('id');
    this.loadCategorias();
    this.loadMarcas();
    this.loadProveedores();
    this.loadProducts();

    if (this.productId) {
      this.isEditMode = true; // Establece el modo de edición
      this.loadProduct();
    } else {
      this.isEditMode = false; // Establece el modo de visualización
    }
  }


  loadCategorias(): void {
    this.categoriaService.getCategorias().subscribe(
      (data) => {
        console.log('Categorías cargadas:', data);
        this.categorias = data;
      },
      (error) => {
        console.error('Error al cargar las categorías', error);
      }
    );
  }
  

  loadMarcas(): void {
    this.marcaService.getMarcas().subscribe(
      (data) => {
        this.marcas = data;
      },
      (error) => {
        console.error('Error al cargar las marcas', error);
      }
    );
  }

  loadProveedores(): void {
    this.proveedorService.getProveedores().subscribe(
      (data) => {
        this.proveedores = data;
      },
      (error) => {
        console.error('Error al cargar los proveedores', error);
      }
    );
  }



  loadProduct(): void {
    if (this.productId) {
      this.productService.getProduct(this.productId).subscribe(product => {
        // Asegúrate de que el producto devuelto tiene los campos correctos
        this.productFormEdit.patchValue(product);
      });
    }
  }
  
  
 

  openChangeImageModal(product: any): void {
    console.log('Producto:', product); // Verifica el objeto product
  
    this.productId = product.id;
    const BASE_URL = 'http://127.0.0.1:8000/storage/';

    // Asumiendo que product.imageUrl contiene solo la ruta relativa
    this.currentImageUrl = `${BASE_URL}${product.imagen}`;
        
    this.modalService.open(this.changeImageModal); // Abre el modal
  }
  
  
  
  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      // Opcional: Previsualiza la imagen
      const reader = new FileReader();
      reader.onload = () => this.currentImageUrl = reader.result as string;
      reader.readAsDataURL(file);
    }
  }

  onImageChange(): void {
  // Verifica si `productId` no es null y es un número válido
  const numericProductId = Number(this.productId);

  if (this.selectedFile && !isNaN(numericProductId)) {
    this.productService.updateProductImage(numericProductId, this.selectedFile)
      .subscribe(
        () => {
          Swal.fire({
            icon: 'success',
            title: 'Imagen actualizada',
            text: 'La imagen se ha actualizado exitosamente.',
          }).then(() => {
            this.loadProducts(); // Actualiza la lista de productos
            this.modalService.dismissAll(); // Cierra el modal
          });
        },
        (error) => {
          console.error('Error al actualizar la imagen', error);
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al actualizar la imagen.',
          });
        }
      );
  } else {
    Swal.fire({
      icon: 'warning',
      title: 'Datos faltantes',
      text: 'Por favor, selecciona una imagen y verifica que el ID del producto esté correcto.',
    });
  }
}

  

  



  openEditModal(product: any): void {
    this.productId = product.id;
    this.isEditMode = true; // Establece el modo de edición
    this.productFormEdit.patchValue({
      nombre: product.nombre || '',
      caracteristicas: product.caracteristicas || '',
      descripcion: product.descripcion || '',
      precio: product.precio || '',
      stock: product.stock || '',
      stock_minimo: product.stock_minimo || '',
      FK_categoria: product.FK_categoria || '',
      FK_proveedor: product.FK_proveedor || '',
      FK_marca: product.FK_marca || '',
      precio_costo: product.precio_costo || '',
      precio_mayoreo: product.precio_mayoreo || '',
      precio_oferta: product.precio_oferta || '',
      cantidad_producto_mayoreo: product.cantidad_producto_mayoreo || '',
      estado: product.estado || '',
      fecha_creacion: product.fecha_creacion || '',
      codigo_barras: product.codigo_barras || '',
      imagen: product.imagen || ''
    });
    this.modalService.open(this.editProductModal);
  }

  
  onSubmit(): void {


    if (this.productId) {
      this.updateProduct(); // Actualiza el producto
    } else {
      this.addProduct(); // Agrega un nuevo producto
    }
    this.modalService.dismissAll();
  }
  

  
  
  updateProduct(): void {
    if (this.productId) {
      this.productService.updateProduct(this.productId, this.productFormEdit.value).subscribe(
        () => {
          Swal.fire({
            icon: 'success',
            title: '¡Producto actualizado!',
            text: 'El producto se ha actualizado exitosamente.',
          }).then(() => {
            this.loadProducts();

            this.router.navigate(['/administrador/productos']); // Navega a la lista de productos
          });
        },
        (error) => {
          console.error('Error al actualizar el producto', error);
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al actualizar el producto.',
          });
        }
      );
    }
  }
  openAddProductModal(content: TemplateRef<any>): void {
    this.modalService.open(content);
  }

  addProduct(): void {
    // Crear un objeto FormData
    const formData = new FormData();
  
    // Añadir los valores del formulario a FormData
    for (const key in this.productForm.value) {
      if (this.productForm.value.hasOwnProperty(key)) {
        formData.append(key, this.productForm.value[key]);
      }
    }
  
    // Añadir el archivo de imagen al FormData
    const imageFile = (document.querySelector('#imagen') as HTMLInputElement).files?.[0];
    if (imageFile) {
      formData.append('imagen', imageFile);
    }
  
    // Enviar el FormData al servicio
    this.productService.createProduct(formData).subscribe(
      () => {
        Swal.fire({
          icon: 'success',
          title: '¡Producto agregado!',
          text: 'El producto se ha agregado exitosamente.',
        }).then(() => {
          this.loadProducts();
          this.modalService.dismissAll(); // Cierra el modal
          this.router.navigate(['/administrador/productos']); // Navega a la lista de productos
        });
      },
      (error) => {
        console.error('Error al agregar el producto', error);
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Hubo un problema al agregar el producto.',
        });
      }
    );
  }
  


  

  loadProducts(): void {
    this.productService.getProducts().subscribe(
      (data) => {
        this.products = data
          .filter(product => product.estado === 1)
          .map(product => ({
            id: product.pk_producto,
            nombre: product.nombre,
            caracteristicas: product.caracteristicas,
            descripcion: product.descripcion,
            precio: product.precio,
            stock: product.stock,
            stock_minimo: product.stock_minimo,
            categoria: product.FK_categoria,
            proveedor: product.FK_proveedor,
            marca: product.FK_marca,
            precio_costo: product.precio_costo,
            precio_mayoreo: product.precio_mayoreo,
            precio_oferta: product.precio_oferta,
            cantidad_producto_mayoreo: product.cantidad_producto_mayoreo,
            estado: product.estado,
            fecha_creacion: product.fecha_creacion,
            created_at: product.created_at,
            updated_at: product.updated_at,
            codigo_barras: product.codigo_barras,
            imagen: product.imagen
          }));
      },
      (error) => console.error('Error al cargar los productos', error)
    );
  }
  
  

  getImageUrl(imagePath: string): string {
    const url = `http://127.0.0.1:8000/storage/${imagePath}`;
    console.log('Image URL:', url); // Verifica que la URL sea correcta
    return url;
}



  
deleteProduct(id: number): void {
  Swal.fire({
    title: '¿Estás seguro?',
    text: "¡No podrás revertir esto!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Sí, eliminarlo!'
  }).then((result) => {
    if (result.isConfirmed) {
      this.productService.deleteProduct(id).subscribe(
        () => {
          Swal.fire(
            '¡Eliminado!',
            'El producto ha sido eliminado.',
            'success'
          ).then(() => {
            this.loadProducts();
          });
        },
        (error) => {
          console.error('Error al eliminar el producto', error);
          Swal.fire(
            'Error',
            'Hubo un problema al eliminar el producto.',
            'error'
          );
        }
      );
    }
  });
}

addStock(id: number): void {
  const stockToAdd = prompt('Ingrese la cantidad a agregar al stock');
  if (stockToAdd) {
    const quantity = parseInt(stockToAdd, 10);
    if (quantity > 0) {
      this.productService.increaseProductStock(id, quantity).subscribe(
        () => {
          Swal.fire(
            'Stock actualizado!',
            'Se ha aumentado el stock del producto.',
            'success'
          ).then(() => {
            this.loadProducts();
          });
        },
        (error) => {
          console.error('Error al actualizar el stock', error);
          Swal.fire(
            'Error',
            'Hubo un problema al actualizar el stock.',
            'error'
          );
        }
      );
    }
  }
}

removeStock(id: number): void {
  const stockToRemove = prompt('Ingrese la cantidad a disminuir del stock');
  if (stockToRemove) {
    const quantity = parseInt(stockToRemove, 10);
    if (quantity > 0) {
      this.productService.decreaseProductStock(id, quantity).subscribe(
        () => {
          Swal.fire(
            'Stock actualizado!',
            'Se ha disminuido el stock del producto.',
            'success'
          ).then(() => {
            this.loadProducts();
          });
        },
        (error) => {
          console.error('Error al actualizar el stock', error);
          Swal.fire(
            'Error',
            'Hubo un problema al actualizar el stock.',
            'error'
          );
        }
      );
    }
  }
}




}