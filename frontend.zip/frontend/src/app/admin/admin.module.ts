// src/app/admin/admin.module.ts (o el módulo relevante)
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardComponent } from './dashboard/dashboard.component';
import { ProveedorComponent } from './proveedor2/proveedor2.component'; // Ajusta la ruta si es necesario
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MarcaComponent } from './marca/marca.component';
import { ReservationManagementComponent } from './reservation-management/reservation-management.component';
import { ReservationService } from '../services/reservation.service'; // Asegúrate de que el servicio esté importado

@NgModule({
  declarations: [
    AdminDashboardComponent,
    ProveedorComponent,
    MarcaComponent,
    ReservationManagementComponent
    
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [ReservationService],
  bootstrap: [],

  exports: [
    AdminDashboardComponent,
    ProveedorComponent
  ]
})
export class AdminModule { }
