import { Component, OnInit } from '@angular/core';
import { GastoService } from '../../services/gasto.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2'; // Asegúrate de haber instalado sweetalert2

@Component({
  selector: 'app-gasto',
  templateUrl: './gasto.component.html',
  styleUrls: ['./gasto.component.scss']
})
export class GastoComponent implements OnInit {
  gastos: any[] = []; // Usar 'any' en lugar de 'Gasto[]'
  gastoForm: FormGroup;
  editMode = false;
  editGastoId: number | null = null;

  constructor(private gastoService: GastoService, private fb: FormBuilder) {
    const today = new Date().toISOString().split('T')[0]; // Obtiene la fecha actual en formato YYYY-MM-DD
    this.gastoForm = this.fb.group({
      descripcion: ['', [Validators.required, Validators.maxLength(255)]],
      monto: ['', [Validators.required, Validators.min(0)]],
      fecha: [today, [Validators.required]], // Establece la fecha actual como valor predeterminado
      estado: ['', [Validators.required]]
    });
  }
  

  ngOnInit(): void {
    this.loadGastos();
  }

  loadGastos(): void {
    this.gastoService.getGastos().subscribe(
      data => this.gastos = data,
      error => console.error('Error al cargar gastos', error)
    );
  }

  addGasto(): void {
    this.editMode = false;
    this.gastoForm.reset({
      estado: 1 // Por defecto se activa
    });
  }

  onSubmit(): void {
    if (this.gastoForm.valid) {
      if (this.editMode && this.editGastoId) {
        this.gastoService.updateGasto(this.editGastoId, this.gastoForm.value).subscribe(
          response => {
            Swal.fire('Éxito', 'Gasto actualizado con éxito', 'success');
            this.loadGastos();
            this.resetForm();
          },
          error => {
            Swal.fire('Error', 'Error al actualizar gasto', 'error');
            console.error('Error al actualizar gasto', error);
          }
        );
      } else {
        this.gastoService.addGasto(this.gastoForm.value).subscribe(
          response => {
            Swal.fire('Éxito', 'Gasto agregado con éxito', 'success');
            this.loadGastos();
            this.resetForm();
          },
          error => {
            Swal.fire('Error', 'Error al agregar gasto', 'error');
            console.error('Error al agregar gasto', error);
          }
        );
      }
    }
  }

  editGasto(gasto: any): void {
    this.editMode = true;
    this.editGastoId = gasto.pk_gastos;
    this.gastoForm.patchValue(gasto);
  }

  deleteGasto(id: number): void {
    Swal.fire({
      title: '¿Estás seguro?',
      text: '¡No podrás recuperar este gasto!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, eliminarlo'
    }).then((result) => {
      if (result.isConfirmed) {
        this.gastoService.deleteGasto(id).subscribe(
          response => {
            Swal.fire('Eliminado', 'El gasto ha sido eliminado.', 'success');
            this.loadGastos();
          },
          error => {
            Swal.fire('Error', 'Error al eliminar gasto', 'error');
            console.error('Error al eliminar gasto', error);
          }
        );
      }
    });
  }

  confirmarCambioEstado(gasto: any): void {
    const nuevoEstado = gasto.estado === 1 ? 2 : 1;
    Swal.fire({
      title: '¿Estás seguro?',
      text: `¿Quieres ${nuevoEstado === 1 ? 'activar' : 'desactivar'} este gasto?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: `${nuevoEstado === 1 ? 'Sí, activar' : 'Sí, desactivar'}`
    }).then((result) => {
      if (result.isConfirmed) {
        const gastoActualizado = { ...gasto, estado: nuevoEstado };
        this.gastoService.toggleStatus(gastoActualizado).subscribe(
          response => {
            Swal.fire('Éxito', `Gasto ${nuevoEstado === 1 ? 'activado' : 'desactivado'} con éxito`, 'success');
            this.loadGastos();
          },
          error => {
            Swal.fire('Error', 'Error al cambiar el estado del gasto', 'error');
            console.error('Error al cambiar el estado del gasto', error);
          }
        );
      }
    });
  }

  resetForm(): void {
    this.gastoForm.reset();
    this.editMode = false;
    this.editGastoId = null;
  }
}
