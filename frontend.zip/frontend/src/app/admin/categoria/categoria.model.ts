// categoria.model.ts
export interface Categoria {
    pk_categoria: number;
    nombre: string;
    estado: number;
  }
  