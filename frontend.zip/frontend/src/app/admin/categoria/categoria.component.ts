import { Component, OnInit } from '@angular/core';
import { CategoriaService } from '../../services/categoria.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2'; // Asegúrate de haber instalado sweetalert2
import { Categoria } from './categoria.model'; 

@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.component.html',
  styleUrls: ['./categoria.component.scss']
})
export class CategoriaComponent implements OnInit {
  categorias: Categoria[] = [];
  categoriaForm: FormGroup;
  editMode = false;
  editCategoriaId: number | null = null;

  constructor(private categoriaService: CategoriaService, private fb: FormBuilder) {
    this.categoriaForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.maxLength(100)]],
      estado: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadCategorias();
    this.setupFormForAdding(); // Configura el formulario al iniciar
  }

  loadCategorias(): void {
    this.categoriaService.getCategorias().subscribe(
      data => this.categorias = data,
      error => console.error('Error al cargar categorías', error)
    );
  }
  setupFormForAdding(): void {
    this.categoriaForm.reset({ estado: 1 }); // Estado predeterminado al agregar
    this.categoriaForm.get('estado')?.disable(); // Deshabilitar el estado al agregar
  }

  addCategoria(): void {
    this.editMode = false;
    this.categoriaForm.reset({ estado: 1 }); // Estado predeterminado al agregar
    this.categoriaForm.get('estado')?.disable(); // Deshabilitar el estado al agregar
  }


  onSubmit(): void {
    if (this.categoriaForm.valid) {
      if (this.editMode && this.editCategoriaId) {
        this.categoriaService.updateCategoria(this.editCategoriaId, this.categoriaForm.value).subscribe(
          response => {
            console.log('Categoría actualizada', response);
            this.loadCategorias();
            this.resetForm();
          },
          error => console.error('Error al actualizar categoría', error)
        );
      } else {
        this.categoriaService.createCategoria(this.categoriaForm.value).subscribe(
          response => {
            console.log('Categoría agregada', response);
            this.loadCategorias();
            this.resetForm();
          },
          error => console.error('Error al agregar categoría', error)
        );
      }
    }
  }


  editCategoria(categoria: Categoria): void {
    this.editMode = true;
    this.editCategoriaId = categoria.pk_categoria;
    this.categoriaForm.patchValue(categoria);
    this.categoriaForm.get('estado')?.enable(); // Habilitar el estado durante la edición
  }
  
  deleteCategoria(id: number): void {
    if (confirm('¿Estás seguro de que deseas eliminar esta categoría?')) {
      this.categoriaService.deleteCategoria(id).subscribe(
        response => {
          console.log('Categoría eliminada', response);
          this.loadCategorias();
        },
        error => console.error('Error al eliminar categoría', error)
      );
    }
  }

  resetForm(): void {
    this.categoriaForm.reset({ estado: 1 }); // Establece el estado predeterminado al resetear
    this.editMode = false;
    this.editCategoriaId = null;
    this.categoriaForm.get('estado')?.disable(); // Deshabilitar el estado después de la edición
  }

  confirmarCambioEstado(categoria: Categoria): void {
    Swal.fire({
      title: '¿Estás seguro?',
      text: `¿Quieres ${categoria.estado === 1 ? 'desactivar' : 'activar'} esta categoría?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.cambiarEstado(categoria);
      }
    });
  }

  cambiarEstado(categoria: Categoria): void {
    const nuevoEstado = categoria.estado === 1 ? 2 : 1; // Cambiar el estado entre 1 y 2
    
    this.categoriaService.updateCategoria(categoria.pk_categoria, { estado: nuevoEstado })
      .subscribe(
        response => {
          console.log('Estado actualizado', response);
          // Actualiza la categoría en la lista local
          const index = this.categorias.findIndex(c => c.pk_categoria === categoria.pk_categoria);
          if (index > -1) {
            this.categorias[index].estado = nuevoEstado;
          }
        },
        error => {
          console.error('Error al cambiar el estado', error);
        }
      );
  }
}
