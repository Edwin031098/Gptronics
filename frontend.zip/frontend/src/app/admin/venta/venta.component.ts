import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProductoService } from '../../services/producto.service';
import Swal from 'sweetalert2'; // Importa SweetAlert2
import { MatSelectChange } from '@angular/material/select'; // Importa MatSelectChange

@Component({
  selector: 'app-venta',
  templateUrl: './venta.component.html',
  styleUrls: ['./venta.component.scss']
})
export class VentaComponent implements OnInit {
  ventaForm: FormGroup;
  productos: any[] = []; // Lista de productos desde el servicio
  filteredProducts: any[] = [];
  productosAgregados: any[] = []; // Lista de productos agregados a la venta
  total: number = 0; // Total de la venta
  priceOptions: any[] = [
    { value: 'precio', label: 'Precio Normal' },
    { value: 'precio_mayoreo', label: 'Precio Mayoreo' },
    { value: 'precio_oferta', label: 'Precio Oferta' }
  ];
  selectedProductPrice: number = 0; // Propiedad para el precio del producto seleccionado

  constructor(private productoService: ProductoService, private fb: FormBuilder) {
    this.ventaForm = this.fb.group({
      product: [''],
      price: [''],
      quantity: [1],
      priceType: ['precio'] // Añadir el control para el tipo de precio
    });
  }

  ngOnInit() {
    // Cargar todos los productos al iniciar
    this.productoService.getProductos().subscribe(data => {
      this.productos = data;
      this.filteredProducts = this.productos; // Inicialmente mostrar todos los productos
    });

    // Realizar filtrado en el lado del cliente
    this.ventaForm.get('product')?.valueChanges.subscribe(value => {
      this.onSearch(value);
    });

    // Actualizar el precio cuando cambia el tipo de precio
    this.ventaForm.get('priceType')?.valueChanges.subscribe(value => {
      this.onPriceTypeChange(value);
    });
  }

  onSearch(value: string): void {
    if (!value) {
      this.filteredProducts = this.productos;
      return;
    }

    const filterValue = value.toLowerCase();
    this.filteredProducts = this.productos.filter(product => 
      product.nombre.toLowerCase().includes(filterValue) || 
      product.codigo_barras.toLowerCase().includes(filterValue)
    );
  }

  selectProduct(product: any) {
    this.ventaForm.patchValue({
      product: product.pk_producto,
      price: product.precio // El precio inicial
    });
    this.selectedProductPrice = product.precio;
  }

  onPriceTypeChange(priceType: string) {
    const producto = this.productos.find(p => p.pk_producto === this.ventaForm.value.product);
    if (producto) {
      this.ventaForm.patchValue({
        price: producto[priceType] // Actualiza el precio según el tipo seleccionado
      });
      this.selectedProductPrice = producto[priceType]; // Actualiza el precio seleccionado
    }
  }

  removeProduct(producto: any) {
    // Elimina el producto de la lista
    this.productosAgregados = this.productosAgregados.filter(p => p.pk_producto !== producto.pk_producto);
    
    // Recalcular el total
    this.total = this.productosAgregados.reduce((acc, prod) => acc + (prod.cantidad * prod.precio), 0);
  }

  editPrice(producto: any) {
    const currentPrice = producto.precio;
    const newPrice = prompt(
      `Ingrese el nuevo precio (actual: ${currentPrice}):`,
      currentPrice.toString()
    );

    if (newPrice !== null) {
      const newPriceNumber = Number(newPrice);
      if (!isNaN(newPriceNumber)) {
        producto.precio = newPriceNumber;
        
        // Recalcular el total
        this.total = this.productosAgregados.reduce((acc, prod) => acc + (prod.cantidad * prod.precio), 0);
      } else {
        alert('El precio ingresado no es válido.');
      }
    }
  }

  submitVenta() {
    const formValue = this.ventaForm.value;
    const producto = this.productos.find(p => p.pk_producto === formValue.product); // Busca el producto completo

    if (producto) {
      this.productosAgregados.push({
        pk_producto: producto.pk_producto,
        nombre: producto.nombre, // Agrega el nombre del producto
        cantidad: formValue.quantity,
        precio: formValue.price
      });

      // Calcular el total
      this.total += formValue.quantity * formValue.price;

      // Resetear el formulario
      this.ventaForm.reset({
        quantity: 1 // Restaurar la cantidad a 1
      });
    }
  }

  confirmarVenta() {
    if (confirm('¿Estás seguro de que deseas confirmar la venta?')) {
      const ventaData = {
        productos: this.productosAgregados,
        total: this.total
      };

      this.productoService.registrarVenta(ventaData).subscribe(response => {
        Swal.fire({
          title: 'Venta Confirmada',
          text: 'La venta se ha realizado con éxito.',
          icon: 'success',
          confirmButtonText: 'OK'
        });

        this.productosAgregados = [];
        this.total = 0;
        this.ventaForm.reset({
          quantity: 1
        });
      }, error => {
        console.error('Error al confirmar la venta:', error);
      });
    }
  }
}
