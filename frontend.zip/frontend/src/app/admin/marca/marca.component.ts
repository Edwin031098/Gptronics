import { Component, OnInit } from '@angular/core';
import { MarcaService } from '../../services/marca.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-marca',
  templateUrl: './marca.component.html',
  styleUrls: ['./marca.component.scss']
})
export class MarcaComponent implements OnInit {
  marcas: any[] = [];
  marcaForm: FormGroup;
  editMode = false;
  editMarcaId: number | null = null;

  constructor(private marcaService: MarcaService, private fb: FormBuilder) {
    this.marcaForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.maxLength(100)]],
      estado: [{ value: '', disabled: true }, [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadMarcas();
  }

  loadMarcas(): void {
    this.marcaService.getMarcas().subscribe(
      data => this.marcas = data,
      error => console.error('Error al cargar marcas', error)
    );
  }

  addMarca(): void {
    this.editMode = false;
    this.marcaForm.reset();
    this.marcaForm.controls['estado'].disable(); // Deshabilitar el campo de estado
  }

  onSubmit(): void {
    if (this.marcaForm.valid) {
      if (this.editMode && this.editMarcaId) {
        this.marcaService.updateMarca(this.editMarcaId, this.marcaForm.value).subscribe(
          response => {
            console.log('Marca actualizada', response);
            this.loadMarcas();
            this.resetForm();
          },
          error => console.error('Error al actualizar marca', error)
        );
      } else {
        this.marcaService.addMarca({ ...this.marcaForm.value, estado: 1 }).subscribe(
          response => {
            console.log('Marca agregada', response);
            this.loadMarcas();
            this.resetForm();
          },
          error => console.error('Error al agregar marca', error)
        );
      }
    }
  }

  editMarca(marca: any): void {
    this.editMode = true;
    this.editMarcaId = marca.pk_marca;
    this.marcaForm.patchValue(marca);
    this.marcaForm.controls['estado'].enable(); // Habilitar el campo de estado
  }

  deleteMarca(id: number): void {
    if (confirm('¿Estás seguro de que deseas eliminar esta marca?')) {
      this.marcaService.deleteMarca(id).subscribe(
        response => {
          console.log('Marca eliminada', response);
          this.loadMarcas();
        },
        error => console.error('Error al eliminar marca', error)
      );
    }
  }

  resetForm(): void {
    this.marcaForm.reset();
    this.editMode = false;
    this.editMarcaId = null;
  }

  confirmarCambioEstado(marca: any): void {
    Swal.fire({
      title: '¿Estás seguro?',
      text: `¿Quieres ${marca.estado === 1 ? 'desactivar' : 'activar'} esta marca?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed) {
        this.cambiarEstado(marca);
      }
    });
  }

  cambiarEstado(marca: any): void {
    const nuevoEstado = marca.estado === 1 ? 2 : 1;
    this.marcaService.toggleStatus({ ...marca, estado: nuevoEstado }).subscribe(
      response => {
        // Actualiza la marca en la lista local
        marca.estado = nuevoEstado;
      },
      error => {
        console.error('Error al cambiar el estado', error);
      }
    );
  }
}
