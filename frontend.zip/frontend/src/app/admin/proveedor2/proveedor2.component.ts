import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProveedorService } from '../../services/proveedor.service';

declare var bootstrap: any;

@Component({
  selector: 'app-proveedor',
  templateUrl: './proveedor2.component.html',
  styleUrls: ['./proveedor2.component.css']
})
export class ProveedorComponent implements OnInit {
  proveedorForm: FormGroup;
  proveedores: any[] = [];
  editMode: boolean = false;
  editProveedorId: number | null = null;

  constructor(private fb: FormBuilder, private proveedorService: ProveedorService) {
    this.proveedorForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.maxLength(100)]],
      contacto: ['', [Validators.required, Validators.maxLength(100)]],
      telefono: ['', [Validators.required, Validators.maxLength(15)]],
      direccion: ['', [Validators.required, Validators.maxLength(255)]],
      estado: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadProveedores();
  }

  openModal() {
    this.editMode = false;
    this.proveedorForm.reset();
    const modalElement = document.getElementById('proveedorModal');
    if (modalElement && typeof bootstrap !== 'undefined') {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    } else {
      console.error('Elemento modal no encontrado o bootstrap no inicializado');
    }
  }

  onSubmit() {
    if (this.proveedorForm.valid) {
      if (this.editMode && this.editProveedorId) {
        this.proveedorService.updateProveedor(this.editProveedorId, this.proveedorForm.value).subscribe(
          response => {
            console.log('Proveedor actualizado', response);
            this.loadProveedores();
            this.resetForm();
            this.hideModal();
          },
          error => {
            console.error('Error al actualizar proveedor', error);
          }
        );
      } else {
        this.proveedorService.addProveedor(this.proveedorForm.value).subscribe(
          response => {
            console.log('Proveedor agregado', response);
            this.loadProveedores();
            this.resetForm();
            this.hideModal();
          },
          error => {
            console.error('Error al agregar proveedor', error);
          }
        );
      }
    }
  }

  editProveedor(proveedor: any) {
    this.editMode = true;
    this.editProveedorId = proveedor.id;
    this.proveedorForm.patchValue(proveedor);
    const modalElement = document.getElementById('proveedorModal');
    if (modalElement && typeof bootstrap !== 'undefined') {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    } else {
      console.error('Elemento modal no encontrado o bootstrap no inicializado');
    }
  }

  deleteProveedor(id: number) {
    if (confirm('¿Estás seguro de que deseas eliminar este proveedor?')) {
      this.proveedorService.deleteProveedor(id).subscribe(
        response => {
          console.log('Proveedor eliminado', response);
          this.loadProveedores();
        },
        error => {
          console.error('Error al eliminar proveedor', error);
        }
      );
    }
  }

  resetForm() {
    this.proveedorForm.reset();
    this.editMode = false;
    this.editProveedorId = null;
  }

  hideModal() {
    const modalElement = document.getElementById('proveedorModal');
    if (modalElement && typeof bootstrap !== 'undefined') {
      const modal = bootstrap.Modal.getInstance(modalElement);
      if (modal) {
        modal.hide();
      } else {
        console.error('Modal no inicializado correctamente');
      }
    }
  }

  loadProveedores() {
    this.proveedorService.getProveedores().subscribe(
      data => {
        this.proveedores = data;
      },
      error => {
        console.error('Error al cargar proveedores', error);
      }
    );
  }
}
