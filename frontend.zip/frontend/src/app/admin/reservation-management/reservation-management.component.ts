import { Component, OnInit, TemplateRef, ViewChild  } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReservationService } from '../../services/reservation.service'; // Asegúrate de que el servicio esté correctamente importado

@Component({
  selector: 'app-reservation-management',
  templateUrl: './reservation-management.component.html',
  styleUrls: ['./reservation-management.component.scss'] // Corregido `styleUrl` a `styleUrls`
})
export class ReservationManagementComponent implements OnInit {
  reservations: any[] = [];
  reservationDetails: any[] = [];
  totalPrice: number = 0;
  userId: number = 0;
  loading = true;
  error: string | null = null;
  totalAmount: number = 0;
  reservationTotal: number = 0;

  @ViewChild('reservationDetailModal') reservationDetailModal!: TemplateRef<any>;

  constructor(private reservationService: ReservationService, private modalService: NgbModal) {}

  ngOnInit(): void {
    this.loadReservations();
  }

  loadReservations() {
    this.reservationService.getReservations().subscribe(data => {
      this.reservations = data;
    });
  }

 
  openReservationDetailModal(reservationId: number): void {
    this.reservationService.getReservationDetails(reservationId).subscribe(
      (response: any) => {
        console.log('Reservation details response:', response); // Verifica los datos recibidos
        this.reservationDetails = response.details;
        this.reservationTotal = response.total; // Aquí se recibe el total
        this.totalPrice = response.total; // Asigna el total al totalPrice
        this.modalService.open(this.reservationDetailModal, { size: 'lg' });
      },
      (error: any) => {
        console.error('Error fetching reservation details:', error);
        this.error = 'Failed to load reservation details';
      }
    );
  }
  
  deleteReservation(reservationId: number) {
    this.reservationService.deleteReservation(reservationId).subscribe(() => {
      this.loadReservations(); // Recargar reservas después de eliminar
    });
  }
  acceptReservation(reservationId: number): void {
    const fechaRecoger = prompt('Ingrese la fecha de recogida (YYYY-MM-DD):');
    console.log(reservationId);
    if (fechaRecoger) {
      this.reservationService.acceptReservation(reservationId, fechaRecoger).subscribe(
        () => {
          this.loadReservations(); // Recargar reservas después de aceptar
        },
        error => {
          console.error('Error accepting reservation:', error);
        }
      );
    }
  }
  
  markAsCollected(reservationId: number): void {
    if (confirm('¿Estás seguro de que quieres marcar esta reserva como recogida?')) {
        this.reservationService.markAsCollected(reservationId).subscribe(
            response => {
                // Mensaje de éxito (opcional)
                alert('Reserva marcada como recogida y venta registrada.');
                this.loadReservations(); // Recargar reservas después de marcar como recogida
            },
            error => {
                console.error('Error marking reservation as collected:', error);
            }
        );
    }
}
}
