import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { BienvenidoComponent } from './components/bienvenido/bienvenido.component';
import { DashboardComponent } from './components/dashboard/dashboard.component'; // Importa el componente protegido
import { AdminDashboardComponent } from './admin/dashboard/dashboard.component'; // Componente del admin
import { AuthGuard } from './guards/auth.guard'; // Importa el guardia
import { AdminGuard } from './guards/admin.guard';
import { NavbarAdminComponent } from './components/navbar-admin/navbar-admin.component'; // Nueva ruta
import { ProveedorComponent } from './admin/proveedor2/proveedor2.component'; // Usa el nombre correcto del componente
import { CategoriaComponent } from './admin/categoria/categoria.component';
import { MarcaComponent } from './admin/marca/marca.component'; // Ajusta la ruta según sea necesario
import { GastoComponent } from './admin/gasto/gasto.component'; // Importa el componente de gastos
import { ProductComponent } from './admin/product/product.component';
import { VentaComponent } from './admin/venta/venta.component'; // Importa el componente
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import { ReserveComponent } from './reserve/reserve.component';
import { ReservationsComponent } from './reservations/reservations.component';
import { ReservationManagementComponent } from './admin/reservation-management/reservation-management.component';
import { ReportesComponent } from './admin/reportes/reportes.component'; // Ajusta la ruta según la ubicación de tu componente
import { ProductosBetterComponent } from './productos-better/productos-better.component'; // Importa el componente
import { GestionUsuariosComponent } from './gestion-usuarios/gestion-usuarios.component';
import { BetterwareOrdersComponent } from './betterware-orders/betterware-orders.component';
import { AdminOrdersComponent } from './admin-orders/admin-orders.component';

const routes: Routes = [
  { path: '', redirectTo: '/bienvenido', pathMatch: 'full' }, // Redirige a bienvenido si la ruta es vacía

  // Rutas públicas
  { path: 'login', component: LoginComponent }, // Ruta de login
  { path: 'register', component: RegisterComponent }, // Ruta de registro
  { path: 'bienvenido', component: BienvenidoComponent }, // Página de bienvenida pública
  { path: 'products', component: ProductsComponent },

  // Rutas protegidas para el cliente
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] }, // Ruta protegida del cliente
  { path: 'cart', component: CartComponent, canActivate: [AuthGuard] },
  { path: 'reserve/:id', component: ReserveComponent,canActivate: [AuthGuard] },
  { path: 'reservations', component: ReservationsComponent,canActivate: [AuthGuard] },
  { path: 'betterware-orders', component: BetterwareOrdersComponent,canActivate: [AuthGuard] },

  // Rutas para el administrador
  {
    path: 'administrador',
    children: [
      { path: 'dashboard', component: AdminDashboardComponent, canActivate: [AdminGuard] },
      { path: 'proveedor', component: ProveedorComponent, canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
      { path: 'categorias', component: CategoriaComponent , canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
      { path: 'marcas', component: MarcaComponent , canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
      { path: 'gastos', component: GastoComponent , canActivate: [AdminGuard] }, // Usa el nombre correcto del componente
      { path: 'productos/:id', component: ProductComponent , canActivate: [AdminGuard] }, // Para editar un producto
      { path: 'productos', component: ProductComponent , canActivate: [AdminGuard] }, // Para agregar un producto
      { path: 'venta', component: VentaComponent, canActivate: [AdminGuard] }, // Agrega esta línea para la ruta del componente de ventas         
      { path: 'reservations', component: ReservationManagementComponent,canActivate: [AdminGuard] },
      { path: 'reportes', component: ReportesComponent ,canActivate: [AdminGuard] },
      { path: 'productos-better', component: ProductosBetterComponent,canActivate: [AdminGuard] }, // Ruta para el componente ProductosBetter
      { path: 'gestion-usuarios', component: GestionUsuariosComponent,canActivate: [AdminGuard] },
      { path: 'admin-orders', component: AdminOrdersComponent,canActivate: [AdminGuard] },

    ]
  },

  // Redirige a la página de bienvenida si la ruta no se encuentra
  { path: '**', redirectTo: '/bienvenido' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
