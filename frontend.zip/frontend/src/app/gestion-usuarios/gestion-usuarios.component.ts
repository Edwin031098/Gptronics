import { Component,OnInit  } from '@angular/core';
import { UsuarioService } from '../services/usuario.service';

@Component({
  selector: 'app-gestion-usuarios',
  templateUrl: './gestion-usuarios.component.html',
  styleUrl: './gestion-usuarios.component.scss'
})

export class GestionUsuariosComponent implements OnInit {
  usuarios: any[] = [];
  roles = ['admin', 'Cliente', 'Betterware']; // Define roles as needed

  constructor(private usuarioService: UsuarioService) { }

  ngOnInit(): void {
    this.loadUsuarios();
  }

  loadUsuarios(): void {
    this.usuarioService.getUsuarios().subscribe(data => {
      this.usuarios = data;
    });
  }

  updateRol(id: number, role: string): void {
    this.usuarioService.updateRol(id, role).subscribe(() => {
      this.loadUsuarios();
    });
  }
}