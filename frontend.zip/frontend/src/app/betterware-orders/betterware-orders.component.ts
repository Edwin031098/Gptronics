import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../services/auth.service';
import { Observable, of } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-betterware-orders',
  templateUrl: './betterware-orders.component.html',
  styleUrls: ['./betterware-orders.component.scss']
})
export class BetterwareOrdersComponent implements OnInit {
  isListView: boolean = true;
  orders: any[] = [];
  products: any[] = [];
  selectedProducts: any[] = [];
  totalAmount: number = 0;
  filteredProducts: any[] = [];
  orderForm: FormGroup;

  private baseUrl: string = 'http://localhost:8000/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private fb: FormBuilder
  ) {
    this.orderForm = this.fb.group({
      searchCode: [''],
      quantity: ['']
    });
  }

  ngOnInit(): void {
    this.loadOrders();
    this.loadProducts();
    this.orderForm.get('searchCode')?.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    ).subscribe(filteredProducts => this.filteredProducts = filteredProducts);
  }

  loadOrders(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.http.get<any[]>(`${this.baseUrl}/orders/${userId}`).subscribe(
        data => this.orders = data,
        error => console.error('Error loading orders:', error)
      );
    }
  }

  loadProducts(): void {
    this.http.get<any[]>(`${this.baseUrl}/productos-better`).subscribe(
      data => {
        this.products = data.filter(product => product.codigo && product.nombre);
        this.filteredProducts = this.products;
      },
      error => console.error('Error loading products:', error)
    );
  }
  
  filterProducts(): void {
    const searchCode = this.orderForm.get('searchCode')?.value.toLowerCase() || '';
    this.filteredProducts = this.products.filter(product =>
      (product.codigo && product.codigo.toLowerCase().includes(searchCode)) ||
      (product.nombre && product.nombre.toLowerCase().includes(searchCode))
    );
  }

  selectProduct(product: any): void {
    const quantity = this.orderForm.get('quantity')?.value || 1;
    const existingProduct = this.selectedProducts.find(p => p.codigo === product.codigo);
    if (existingProduct) {
      existingProduct.quantity += quantity;
    } else {
      this.selectedProducts.push({ ...product, quantity });
    }
    this.calculateTotal();
  }

  calculateTotal(): void {
    this.totalAmount = this.selectedProducts.reduce((total, product) =>
      total + (product.precio * product.quantity), 0);
  }

  placeOrder(): void {
    if (this.selectedProducts.length === 0) {
      alert('No products selected');
      return;
    }

    const userId = this.authService.getUserId();
    const newOrder = {
      user_id: userId,
      products: this.selectedProducts.map(p => ({ id: p.id, quantity: p.quantity })),
      total: this.totalAmount
    };

    this.http.post<any>(`${this.baseUrl}/orders`, newOrder).subscribe(
      () => {
        alert('Order placed successfully');
        this.selectedProducts = [];
        this.totalAmount = 0;
        this.loadOrders();
        this.isListView = true;
      },
      error => console.error('Error placing order:', error)
    );
  }

  toggleView(): void {
    this.isListView = !this.isListView;
  }

  private _filter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.products.filter(product =>
      (product.codigo && product.codigo.toLowerCase().includes(filterValue)) ||
      (product.nombre && product.nombre.toLowerCase().includes(filterValue))
    );
  }
}
