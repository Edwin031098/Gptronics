import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BetterwareOrdersComponent } from './betterware-orders.component';

describe('BetterwareOrdersComponent', () => {
  let component: BetterwareOrdersComponent;
  let fixture: ComponentFixture<BetterwareOrdersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BetterwareOrdersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BetterwareOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
