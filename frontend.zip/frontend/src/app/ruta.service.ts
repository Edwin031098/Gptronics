import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class RutaService {
  private apiUrl = 'http://localhost:8000/api/get-url'; // Cambia esto según tu configuración

  constructor(private http: HttpClient) { }

  getUrl(accion: string): Observable<any> {
    return this.http.post<any>(this.apiUrl, { accion });
  }
}
