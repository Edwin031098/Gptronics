import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { BienvenidoComponent } from './components/bienvenido/bienvenido.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { NavbarClientComponent } from './components/navbar-client/navbar-client.component';
import { NavbarAdminComponent } from './components/navbar-admin/navbar-admin.component';
import { AdminModule } from './admin/admin.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CategoriaComponent } from './admin/categoria/categoria.component'; // Importa NgbModule
import { MarcaComponent } from './admin/marca/marca.component';
import { GastoComponent } from './admin/gasto/gasto.component';
import { ProductComponent } from './admin/product/product.component';
import { VentaComponent } from './admin/venta/venta.component'; // Asegúrate de que la ruta sea correcta

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import { ReserveComponent } from './reserve/reserve.component';
import { ReservationsComponent } from './reservations/reservations.component';
import { ReservationManagementComponent } from './admin/reservation-management/reservation-management.component';
import { ReportesComponent } from './admin/reportes/reportes.component';
import { ProductosBetterComponent } from './productos-better/productos-better.component';
import { GestionUsuariosComponent } from './gestion-usuarios/gestion-usuarios.component';
import { BetterwareOrdersComponent } from './betterware-orders/betterware-orders.component';
import { AdminOrdersComponent } from './admin-orders/admin-orders.component';




@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    BienvenidoComponent,
    DashboardComponent,
    NavbarClientComponent,
    NavbarAdminComponent,
    CategoriaComponent,
    GastoComponent,
    ProductComponent,
    VentaComponent,
    ProductsComponent,
    CartComponent,
    ReserveComponent,
    ReservationsComponent,
    ReportesComponent,
    ProductosBetterComponent,
    GestionUsuariosComponent,
    BetterwareOrdersComponent,
    AdminOrdersComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    SweetAlert2Module.forRoot(),
    FormsModule,
    NgbModule,
    AdminModule,    
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatButtonModule,// Asegúrate de que AdminModule está importado aquí

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
