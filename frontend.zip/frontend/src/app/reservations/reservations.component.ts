import { Component ,OnInit, TemplateRef, ViewChild  } from '@angular/core';
import { ReservationService } from '../services/reservation.service';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../services/auth.service'; // Asegúrate de que AuthService esté importado
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-reservations',
  templateUrl: './reservations.component.html',
  styleUrl: './reservations.component.scss'
})


export class ReservationsComponent implements OnInit {
  reservations: any[] = [];
  userId: number = 0;
  loading = true;
  error: string | null = null;
  totalPrice: number = 0; // Agregamos esta propiedad para el total
  totalAmount: number = 0; // Total de todas las reservas
  reservationDetails: any[] = [];
  @ViewChild('reservationDetailModal') reservationDetailModal!: TemplateRef<any>;
  reservationTotal: number = 0; // Agrega esta línea para la propiedad del total

  constructor(
    private reservationService: ReservationService,
    private route: ActivatedRoute,
    private authService: AuthService,
    private modalService: NgbModal
  ) {}



  ngOnInit(): void {
    this.loadReservations();
  }




  loadReservations(): void {
    const userId = this.authService.getUserId();
    if (userId !== null) {
      this.reservationService.getUserReservations(userId).subscribe(
        data => {
          this.reservations = data;
          this.calculateTotalAmount(); // Calcular el total después de cargar las reservas
          this.loading = false;
        },
        error => {
          console.error('Error fetching reservations:', error);
          this.error = 'Failed to load reservations';
          this.loading = false;
        }
      );
    } else {
      this.error = 'User ID not found';
      this.loading = false;
    }
  }
  calculateTotalAmount(): void {
    this.totalAmount = this.reservations.reduce((sum, reservation) => sum + parseFloat(reservation.total), 0);
  }

  openReservationDetailModal(reservationId: number): void {
    this.reservationService.getReservationDetails(reservationId).subscribe(
      (response: any) => {
        this.reservationDetails = response.details;
        this.reservationTotal = response.total; // Aquí se recibe el total
        this.modalService.open(this.reservationDetailModal, { size: 'lg' });
      },
      (error: any) => {
        console.error('Error fetching reservation details:', error);
        this.error = 'Failed to load reservation details';
      }
    );
  }



  deleteReservation(reservationId: number): void {
    if (confirm('¿Estás seguro de que quieres eliminar esta reserva?')) {
      this.reservationService.deleteReservation(reservationId).subscribe(
        () => {
          // Eliminar la reserva de la lista local después de la eliminación exitosa
          this.reservations = this.reservations.filter(reservation => reservation.id !== reservationId);
        },
        error => {
          console.error('Error deleting reservation:', error);
        }
      );
    }
  }

}