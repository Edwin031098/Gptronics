// tailwind.config.js
module.exports = {
  content: [
    "./src/**/*.{html,ts}",  // Incluye las rutas a tus archivos HTML y TS
    "./node_modules/flowbite/**/*.js" // add this line
  ],
  theme: {
    extend: {},
  },
  plugins: [
    require('@tailwindcss/aspect-ratio'),
    require('flowbite/plugin') // add this line
    // otros plugins si es necesario
  ],
}
